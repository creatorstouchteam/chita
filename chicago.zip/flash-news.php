<!doctype html>
<html lang="en">
<head>
    <!-- important for compatibility charset -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta name="description" content="">
    
    <!-- important for responsiveness remove to make your site non responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- FavIcon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
    
    <!-- Animation CSS -->
    <link rel="stylesheet" type="text/css" href="css/animate.css" media="all" />
    
    <!-- Foundation CSS File -->
    <link rel="stylesheet" type="text/css" href="css/foundation.min.css" media="all" />
    
    <!-- Font Awesome CSS File -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" media="all" />
    
    <!-- Owl Carousel CSS File -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" media="all" />
    
    <!-- Theme Styles CSS File -->
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    
    <!-- Google Fonts For Stylesheet --> 
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CMontserrat:400,700" rel="stylesheet" type="text/css" />
    
    
</head>

<body>
    <!-- Page Preloader -->
    <div id="loading">
        <div id="loading-center">
            <div id="loading-center-absolute">
            	<div id="object"></div>
            </div>
        </div>
    </div>
    <!-- Page Preloader Ends /-->

	<!-- Main Container -->
    <div class="main-container">
    	
        <?php include'include/header.php';?>
        <?php			
					include 'include/dbconnect.php';
					$id=$_REQUEST['id'];
					$sql2="SELECT * FROM `resources` WHERE inc_cat_id='$id'";					
					$cont2=mysql_query($sql2) or die(mysql_error($sql2));
					$con2=mysql_fetch_array($cont2);
				$content=$con2['cat_desc'];	
					$name=$con2['cat_name'];
					$path=$con2['path'];
					?>
                    <title><?php echo $name;?> Flash News | Chicago Telangana Association</title>
        <!-- Title Section -->
        <div class="title-section module">
            <div class="row">
        
                <div class="small-12 columns">
                    <h1>Flash News</h1>
                </div><!-- Top Row /-->
        
                <div class="small-12 columns">
                    <ul class="breadcrumbs">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Flash News</a></li>
                        <li><span class="show-for-sr">Current: </span> <?php echo $name;?></li>
                    </ul><!-- Breadcrumbs /-->
                </div><!-- Bottom Row /-->
                
            </div><!-- Row /-->
        </div>
        <!-- Title Section Ends /-->
        
        <!-- Content section -->
        <div class="content-section">
        	
            <!-- Seminar/Events -->
            <div class="module">
                <div class="row">
                    
                    <div class="medium-9 small-12 columns">
                    
                     	<div class="event-thumb">
                        	<img src="pdf/<?php echo $path;?>" alt="" class="thumbnail" width="100%"/>
                        </div><!-- Event Thumb /-->
						<div class="event-content">
                        <h3><?php echo $name;?></h3>
                        	<p><?php echo $content;?></p>
							
                        </div><!-- Events content /-->
                    </div><!-- Events Wrapper Ends /-->
                    
                    <div class="medium-3 small-12 columns sidebar">
                    	
                     <div class="widget">
                        <h2>Flash News</h2>
                        
                        <ul class="menu vertical">
                            <?php include'dbconnect.php';
							$sql="select * from resources ORDER BY `resources`.`inc_cat_id` ASC ";
							$query=mysql_query($sql);
							while($row=mysql_fetch_array($query)){?>
                            <li><a href="latest-news-events.php?id=<?php echo $row['inc_cat_id'];?>">
							<?php echo $row['cat_name'];?> </a></li><?php }?>  
                        </ul>
                    </div>
                    <!-- Widget Ends /-->
                        
                    </div><!-- Sidebar Ends /-->
                    
                </div><!-- Row Ends /-->
            </div>
            <!-- Seminar Events Ends /-->
            
            <!-- Our Teachers -->
	        
    	    <!-- Our Teachers /-->
            
        </div>
        <!-- Content Section Ends /-->
        
        
        <!-- Call to Action box -->
        <div class="call-to-action">
           <div class="row">
                <div class="medium-10 small-12 columns">
                    <h2><i class="fa fa-phone" aria-hidden="true"></i> 	If you Have Any Questions Call Us On <span>(010)123-456-7890</span></h2>
                </div>
                <div class="medium-2 small-12 columns">
                    <a href="#" class="button secondary">Appointment</a>
                </div>
           </div><!-- row /-->
         </div>
        <!-- Call to Action End /-->
        
        <!-- Footer -->
        <?php include'include/footer.php';?>
        <!-- Footer Ends here /-->
        
    </div>
    <!-- Main Container /-->
	
    <a href="#top" id="top" class="animated fadeInUp start-anim"><i class="fa fa-angle-up"></i></a>

    <!-- Including Jquery so All js Can run -->
    <script type="text/javascript" src="js/jquery.js"></script>
    
    <!-- Including Foundation JS so Foundation function can work. -->
    <script type="text/javascript" src="js/foundation.min.js"></script>
    
    <!-- Including Owl Carousel File -->
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    
    <!-- Webful JS -->
    <script src="js/webful.js"></script>
</body>
</html>
