<!DOCTYPE html>
 <?php
 include 'includes/dbconnect.php';
if(isset($_POST['deletesubmit']))
{
$id=$_POST['id'];
$ds="DELETE FROM  tbl_faculty WHERE inc_id='$id'";
$rr=mysql_query($ds);
if($rr)
{
$err="<b><font color='green'>success fully Deleteded</b></font>";
}
}
?>
<html>
	<head>
		<title>Welcome to Chicago Telangana Association - Admin</title>
		<link href="img/icon.png" rel="icon">
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
		<script type="text/javascript" src="js/editor.js"></script>
	</head>
	<body>
		<div id="main">
		<?php	
		$page="FC";
		$locname='';	
		error_reporting(0);
		include 'includes/header.php';//header
		include 'includes/sidebar.php';//header
		parse_str($_SERVER['QUERY_STRING']);
		error_reporting(E_ALL ^ E_NOTICE);
		$page == "Faculty";
		?>	<div id="center-column">
						<div class="top-bar">
					<a href="addFaculty.php" class="button">Add Faculty</a><br/>
					<br/><br/>
				</div>
		<div id="center-column">
			<form method="POST" action="">
				<div class="table">
				<div id="heading">
						<span>View Faculty</span>
				</div>
			<div id="bg">
					<table>
				<tr>
				<td>Select Catgorey:</td><td>
<select name="cmbCat" class="forTextfield" id="cmbCat" onChange="window.location='<?php echo $_SERVER['PHP_SELF']."?pageId=".$_REQUEST['pageId']."&id="?>'+this.value"  >
      <option value="" selected="selected">--Select--</option>
      <?php
	  include 'includes/dbconnect.php';
$query1 = "select * from tbl_catinfra order by cat_name asc";
$result1 = mysql_query($query1);
while($row1 = mysql_fetch_array($result1)){
		$sel="";
		if($id==$row1['inc_cat_id']){ $sel="selected='selected'";}else{$sel=""; }
		echo '<option value="'.$row1['inc_cat_id'].'" '.$sel.' style="font-style:normal">'.$row1['cat_name'].'</option>';
	
}
?>
				  </select>
				</td>			
				</tr>
				</table>
					 <table class="listing" cellpadding="0" cellspacing="0">
                        <tr>
							<th>Name</th>
							<th>Tittle</th>
							<th>Delete</th>
							<th>Edit</th>
                        </tr>
            <?php
				include 'includes/dbconnect.php';
				$id=$_REQUEST['id'];
				$sql2="SELECT * FROM `tbl_faculty` where fac_id='$id' ";					
				$cont2=mysql_query($sql2) ;	
				while($row=mysql_fetch_array($cont2))
          {?>
	<tr>
			<td><?php echo $row['inc_id'];?></td>
			<td><?php echo $row['faculty_name'];?></td>
              	<td>
			<form method="post" action="<?php echo $_SERVER['php_self'];?> " >
             <input type="hidden"  name="id" value="<?php echo $row['inc_id']; ?>" /><input name="deletesubmit" title="delete" type="submit"   value="Delete"   >
         </form> 
			</td>		
		<td>
				<form method="get" action="editfac.php" >
             <input type="hidden"  name="id" value="<?php echo $row['inc_id']; ?>" /><input name="editsubmit" title="delete" type="submit"   value="Edit"   >
         </form>  
			</td>
				</tr>
 <?php }?>		
			
						</table>
						</div--><!--/bg-->
					</form>
				<script type="text/javascript">
				if (document.location.protocol == 'file:') {
				alert("The examples might not work properly on the local file system due to security settings in your browser. Please use a real webserver.");
				}
				</script>
				</div><!--/table-->
			</div><!--/center column-->
			</div>
			    <?php include 'includes/footer.php';?>
		</div><!--/main-->
	</body>
</html>