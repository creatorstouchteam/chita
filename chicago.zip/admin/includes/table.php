<div class="table">
                    <table class="listing form" cellpadding="0" cellspacing="0">
                        <tr>
                            <th class="full" colspan="2">Header Here</th>
                        </tr>
                        <tr>
                            <td width="172"><strong>Lorem Ipsum</strong></td>
                            <td><input type="text" class="text" /></td>
                        </tr>
                        <tr>
                            <td><strong>Lorem Ipsum</strong></td>
                            <td><input type="text" class="text" /></td>
                        </tr>
                        <tr>
                            <td><strong>Lorem Ipsum</strong></td>
                            <td><input type="text" class="text" /></td>
                        </tr>
                        <tr>
                            <td><strong>Lorem Ipsum</strong></td>
                            <td><input type="text" class="text" /></td>
                        </tr>
                    </table>
                </div>