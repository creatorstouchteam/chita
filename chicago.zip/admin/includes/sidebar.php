         <div id="middle">
            <div id="left-column">
                <h3>Menu</h3>
                <ul class="nav">
                    <li><a href="index.php">Home</a></li>
                  
                  <li><a href="imgcat.php">Image Category</a></li>
                  <li><a href="viewdownloads.php">Latest News &amp; Events</a></li>
                  <!--<li><a href="viewnotifications.php">Latest Notifications</a></li> 
                  <li><a href="viewresults.php">Latest Results</a></li> 
                  <li><a href="viewcurrent.php">Current Affairs</a></li>
                  
                  <li><a href="admission_view.php">Registrations</a></li>--> 
                  	 
                </ul>
                <a href="http://chicagotsassociation.com" target='_blank' class="link">CHITA</a>
            </div><!--/left-column-->