                 <div class="top-bar">
                    <a href="#" class="button">ADD NEW </a>
                    <h1>Contents</h1>
                    <div class="breadcrumbs"><a href="#">Homepage</a> / <a href="#">Contents</a></div>
                </div>
                <div class="select-bar">
                    <label>
                        <input type="text" name="textfield" />
                    </label>
                    <label>
                        <input type="submit" name="Submit" value="Search" />
                    </label>
                </div>