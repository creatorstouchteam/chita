 <div id="header">
        <div id="logo"><!--logo-->
			 <img src="img/11.png">
		</div>		
            <ul id="top-navigation">
				<li>
					<a href="index.php" <?php echo ($page == 'Home') ? 'class="active"' : '';?> >Home</a>
				</li>
				
                <li>
					<a href="viewabout.php" <?php echo ($page == 'AV') ? 'class="active"' : '';?>>About us</a>
				</li>
				
                <!--<li>
					<a href="viewcareer.php" <?php echo ($page == 'career') ? 'class="active"' : '';?>>  About Us  </a>
				</li>-->
                
                <li>
					<a href="viewdepartments.php" <?php echo ($page == 'administration') ? 'class="active"' : '';?>>Charity/ Projects</a>
				</li>
                
                <li>
					<a href="viewadmissions.php" <?php echo ($page == 'admissions') ? 'class="active"' : '';?>>Members</a>
				</li>
                
               <!-- <li>
					<a href="viewcampus.php" <?php echo ($page == 'collaboration') ? 'class="active"' : '';?>>Specialities</a>
				</li>-->
                
                <!--<li>
					<a href="viewdownloads.php" <?php echo ($page == 'downloads') ? 'class="active"' : '';?>> Latest Events</a>
				</li>-->
              	<li>
					<a href="viewresources.php" <?php echo ($page == 'resources') ? 'class="active"' : '';?>> Flash News</a>
				</li>
                <!--<li>
					<a href="viewkeyconcepts.php" <?php echo ($page == 'keyconcepts') ? 'class="active"' : '';?>> Downloads</a>
				</li>
                <li>
					<a href="viewathletics.php" <?php echo ($page == 'scope') ? 'class="active"' : '';?>>Student Voice</a>
				</li>-->
                
                <li>
					<a href="images.php" <?php echo ($page == 'gallery') ? 'class="active"' : '';?>>Gallery</a>
				</li>
                
                <li>
					<a href="viewVideo.php" <?php echo ($page == 'Videos') ? 'class="active"' : '';?>>Videos</a>
				</li>
                
				<li>
					<a href="password_change.php" <?php echo ($page == 'Change Password') ? 'class="active"' : '';?>>Change Password</a>
				</li>
				<li>
					<a href="logout.php">Logout</a>
				</li>
            </ul>
        </div><!--/header-->
		      <div id="middle">