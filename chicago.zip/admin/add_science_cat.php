<!DOCTYPE html>
<?php 
if(isset($_POST['submit']))
{
	include 'includes/dbconnect.php';
	 $name=$_POST['name'];
	     $sql="select * from science_fac_cat where cat_name='".$name."'";
         $result = mysql_query($sql);
	     $query=mysql_num_rows($result);
      if($query!=0)
	    {
         echo "<script>alert('Allready exits');</script>";
	 	  }
	  else{
	      $sql="insert into science_fac_cat(cat_name,dt_created) values('".$name."', current_date())";
	     $result = mysql_query($sql);
        header("location:view_science_cat.php");
		echo "<script>alert('Inserted sucfully');</script>";
	  }
}
?>
<html>
	<head>
<title>Welcome to Chicago Telangana Association - Admin</title>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		</head>
<script type="text/javascript" language="javascript" >
function validate()
{
 if (document.getElementById('name').value=="")
           {    
		      alert("Enter Category name");
              document.getElementById('name').focus();
              return false;
           }
}
</script>    
	<body>
		<div id="main">
		<?php $page="Pages11";
		$locname='';
		include 'includes/header.php';//header
        include 'includes/sidebar.php';
		parse_str($_SERVER['QUERY_STRING']);
		error_reporting(E_ALL ^ E_NOTICE);
		?>
	<div id="admin1">
		<form method="POST" action=""  enctype="multipart/form-data" onsubmit="return validate();">
				<span>Add Science Staff Category::</span>
				<table>
				<tr><td>Science Staff Category Name:</td><td><input type="text" name="name" size="45" id="name"></td></tr>
				<tr><td></td><td colspan="2"><input name="submit" type="submit" class="forButton" id="butSubmit"></td></tr>
				</table>
		</form>
		</div><!--/center column-->
		   <?php include 'includes/footer.php';?>
     </div><!--/main-->
	</body>
</html>