<?php include('verification.php');?>
<!DOCTYPE html>
<html>
	<head>
		<title>Chicago Telangana Association - Admin</title>
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link  href="css/admin.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
	<div id="main">
		<?php $page="Slides";
		include 'includes/header.php';//header
		include 'includes/sidebar.php';//leftsidebar
		?>
			<div id="center-column">
				<div class="table">
					<div id="heading">
						<span>Slides</span>
					</div>
					<div class="top-bar">
							<a href="new_slide.php" class="button"> New Slide</a>
					</div>
				<div id='success'>
					<?php 
					parse_str($_SERVER['QUERY_STRING']);
					if(isset($success))
					if($success == 'suc'){
					?>
					<?php echo "Successfully slide uploaded.";?>
					<?php 
					}
					if(isset($success))
					if($success == 'add'){
					?>
					<?php echo "<br/><br/><br/>Added Slide successfully.";?>
					<?php 
						}
					?>
				</div>
				<table class="listing" cellpadding="0" cellspacing="0">
					<tr>
						<th>Small Image</th>
						<th>Image</th>
						<th>Path</th>
						<th>Delete</th>
					</tr>
					<?php  
							include 'includes/dbconnect.php';
							$sql="SELECT * FROM `slides`  ORDER BY   `slide_id` ASC";
							$images=mysql_query($sql) or die(mysql_error());
							$count=mysql_num_rows($images);
								$sno=1;
								while($image=mysql_fetch_array($images)){
									$id=$image['slide_id'];
									?>
									<tr>
										<td>
											<img src="<?php echo '../'.$image['name'];?>" width="80" height="40" alt="<?php echo $name?>"/>
										</td>								
										<td>
											<img src="<?php echo '../'.$image['name'];?>" width="80" height="40" alt="<?php echo $name?>"/>
										</td>
										<td>
											<?php echo $image['path'];?>
										</td>
										<td>
											<a href="slide_modification.php?id=<?php echo $id?>&delete=remove" onClick="return confirm('Are You Sure Want Delete');"><img src="img/hr.gif" width="16" height="16" alt="add" /></a>
										</td>
									</tr>
									<?php 
									$sno++;
									}//while close
										
							?>
					</table>
				</div><!--table-->
			</div><!--/center column-->
			<?php include 'includes/footer.php';?>
	</div><!--/main-->
	
	</body>
</html>
