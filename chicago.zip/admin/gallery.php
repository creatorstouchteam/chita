<?php include('verification.php');?>
<!DOCTYPE html>
<html>
	<head>
  <title>Welcome to Chicago Telangana Association - Admin</title>
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link  href="css/admin.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
	<div id="main">
		<?php $page="Images";
		include 'includes/header.php';
		include 'includes/sidebar.php';
		?>
			<div id="center-column">

				<div class="table">
				<div id="heading">
						<span>Gallery Images</span>
				</div>
				<?php
					$url=$_SERVER['QUERY_STRING'];
					parse_str($url);
				?>
				<div class="top-bar">
					<a href="new_image.php" class="button"> New  Image</a><br/>
					<br/><br/>
				</div>
	<br/><br/>	<br/><br/>
			<div id='success'>
					<?php
					parse_str($_SERVER['QUERY_STRING']);
					if(isset($success))
					if($success == 'suc'){
					?>
					<?php echo "Updated image successfully.";?>
					<?php 
					}
					if(isset($success))
					if($success == 'add'){
					?>
					<?echo "<br/><br/><br/>Added image successfully.";?>
					<?php 
						}
					?>
				</div>
				<?php 	
					$suc='Successfully deleted image';
					$f = 'Image not deleted';
					if(isset($success))
					if($success == 'suc'){
						echo "<div class='error'>".$suc."</div>";
					}
					if(isset($fail))
					if($fail == 'f'){
						echo "<div class='error'>".$f."</div>";
					}
				?>
				<?php 
				$s='Updated home page courses content successfully.';
					if(isset($success))
					if($success == 's'){
							echo "<div class='error'>".$s."</div>";
					}
				if(isset($_GET['submit']) == ''){?>
				
				<h4>Images</h4>
        <table class="listing" cellpadding="0" cellspacing="0">
                        <tr>
							<th>S.NO</th>
							<th>Name</th>
                            <th>Images</th>
					       	<th>Delete</th>
                        </tr>
		<?php 	
				$sql2="SELECT * FROM `gallery`";
				$page2=mysql_query($sql2) or die(mysql_error());
				$rows1=mysql_num_rows($page2);
				$sno=0;
				while($img=mysql_fetch_array($page2)){
				$sno++;		
				$path=$img['path'];
				$id=$img['image_id'];
				$name=$img['name'];
							
	?>
		<tr>
			<td><?php echo $sno;?></td>
			<td><?php echo $name;?></td>
			<td><img src="<?php echo 'img/'.$path;?>" alt="<?php echo $path;?>" width="30" height="30"></td>
			<td>
				<a href="image_modification.php?id=<?php echo $id?>&delete=remove" onClick="return confirm('Are You Sure Want Delete');"><img src="img/hr.gif" width="16" height="16" alt="add" /></a>
										</td>
			</td>
	</tr>
	
	<?php
	}?>
</table>			
<?php	}
				if(isset($_GET['submit'])){?>
					<table class="listing" cellpadding="0" cellspacing="0">
						<tr>
							<th>Name</th>
							<th>Content</th>
							<th>Image Type</th>
							<th>Width</th>
							<th>Height</th>
							<th>Location</th>
							<th>Image</th>
							<th> Edit</th>
							<th>Delete </th>
						</tr>
					<?php 
							if($location=='Choose Page'){
							echo "<b style='color:red;font-size:14px'>please select atleast one page.</b>";
						}
						else{
							include 'includes/dbconnect.php';
							$sql="SELECT * FROM `images` Where `location`='$location' ORDER BY   `image_id` ASC";
							$images=mysql_query($sql) or die(mysql_error());
							$count=mysql_num_rows($images);
							if($count!=0){
								echo '<div id="heading"><span>'.$location. ' page images.</span></div>';
								$sno=1;
								while($image=mysql_fetch_array($images)){
									$id=$image['image_id'];
									?>
									<tr>
										<td>
											<?php echo $image['name'];?>
										</td>
										<td align="justify">
											<?php echo $image['content'];?>
										</td>
										<td>
											<?php echo $image['type'];?>
										</td>
										<td>
											<?php echo $image['width'];?>
										</td>
										<td>
											<?php echo $image['height']?>
										</td>
										<td>
											<?php echo $image['location'];?>
										</td>
										<td>
											<img src="<?php echo '../'.$image['path']?>" width="40" height="40" alt="<?php echo $name?>"/>
										</td>
									<?php if($location=='Home'){
										$link='image_modification.php';?>
										<td>
											<a href="<?php echo $link?>?id=<?php echo $id?>&edit=modify"><img src="img/edit-icon.gif" width="16" height="16" alt="" /></a> 
										</td>
									<?php }
										else{
										$link='other_image_modification.php';?>
										<td>
											<a href="<?php echo $link?>?id=<?php echo $id?>&edit=modify"><img src="img/edit-icon.gif" width="16" height="16" alt="" /></a> 
										</td>
									<?php }?>
										<td>
											<a href="image_modification.php?name=<?php echo $image['name']?>&delete=remove" onClick="return confirm('Are You Sure Want Delete');"><img src="img/hr.gif" width="16" height="16" alt="add" /></a>
										</td>
									</tr>
									<?php 
									$sno++;
									}//while close
							}//if count close
							else{
								echo "<b style='color:red;font-size:14px'>There are not available any images.</b>";
							}//else close
						}//first if else close
					}//if submit close
					?>
					</table>
				</div><!--table-->
			</div><!--/center column-->
			<?php include 'includes/footer.php';?>
	</div><!--/main-->	
	</body>
</html>