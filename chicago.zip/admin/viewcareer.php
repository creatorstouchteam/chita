<!DOCTYPE html>
<?php
if(isset($_POST['deletesubmit']))
{
include 'includes/dbconnect.php';
$id=$_POST['id'];
$ds="DELETE FROM career  WHERE inc_cat_id ='$id'";
$rr=mysql_query($ds);
if($rr)
{
$err="<b><font color='green'>success fully Deleteded</b></font>";
};
}
?>
<html>
	<head>
		<title>Welcome to Chicago Telangana Association - Admin</title>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
		<script type="text/javascript" src="js/editor.js"></script>
	</head>
	<body>
		<div id="main">
		<?php
		$page="career";
		$locname='';
		include 'includes/header.php';
			include 'includes/sidebar.php';
		?>
	<div id="center-column">
		<div class="top-bar">
		<a href="addcareer.php" class="button"> Add About Us </a><br/>
		<br/><br/>
	</div>
		<div id="center-column">
		<form method="POST" action="">
				<div class="table">
				<div id="heading">
						<span>About Us ::</span>
				</div>
				<br/><br/><br/><br/>
			<div id="bg">
					 <table class="listing" cellpadding="0" cellspacing="0">
                        <tr>
							<th>Id</th>
							<th>Tittle</th> 
							<th>Delete</th>
							<th>Edit</th>
                        </tr>
            <?php
				include 'includes/dbconnect.php';
				$sql2="SELECT * FROM `career`";					
				$cont2=mysql_query($sql2) ;	
					$sno=1;
				while($row=mysql_fetch_array($cont2))
			
          {?>
	<tr>
			<td><?php echo $sno++?></td>
			<td><?php echo (strlen($row['cat_desc']) >1) ? substr($row['cat_desc'],0,200) : $row['cat_desc'];?></td>
		<td>
			<form method="post" action="">
             <input type="hidden"  name="id" value="<?php echo $row['inc_cat_id']; ?>" /><input name="deletesubmit" title="delete" type="submit"   value="delete"   >
         </form> 
			</td>		
		<td>
			<form method="get" action="editcareer.php">
             <input type="hidden"  name="id" value="<?php echo $row['inc_cat_id']; ?>" /><input name="editsubmit" title="delete" type="submit"   value="Edit"   >
         </form> 
			</td>
		</tr>
 <?php }?>		
							
						<br />
				</table>
						</div--><!--/bg-->
					</form>
				<script type="text/javascript">
				if (document.location.protocol == 'file:') {
				alert("The examples might not work properly on the local file system due to security settings in your browser. Please use a real webserver.");
				}
				</script>
				</div><!--/table-->
			</div><!--/center column-->
			</div>
			    <?php include 'includes/footer.php';?>
		</div><!--/main-->
	</body>
</html>