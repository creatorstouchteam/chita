<?php include'verification.php';?>

  <?php
 include 'includes/dbconnect.php';
if(isset($_POST['delete']))
{
$id=$_POST['id'];
$ds="DELETE FROM gallery WHERE image_id='$id'";
$rr=mysql_query($ds);
if($rr)
{
$err="<b><font color='green'>success fully Deleteded</b></font>";
}
}
?>

<!DOCTYPE html>

<html>

	<head>

		<title>Welcome to Chicago Telangana Association - Admin</title>

		<link type="text/css" rel="stylesheet" href="css/admin.css"/>

		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />

		<link  href="css/admin.css" rel="stylesheet" type="text/css" />

	</head>

	<body>

	<div id="main">

		<?php

		$page="gallery";

		include 'includes/header.php';//header

		include 'includes/sidebar.php';//leftsidebar

		?>

			<div id="center-column">



				<div class="table">

				<div id="heading">

						<span>Images</span>

				</div>

				<?php

					$url=$_SERVER['QUERY_STRING'];

					parse_str($url);

				?>

						<div class="top-bar">

					<a href="fileupload.php" class="button"> Add New  Image</a><br/>

					<br/><br/>

				</div>

		<br/><br/>	<br/><br/>

				<form action="" method="GET" name="image" onSubmit="return GetSelectedItem()">

				Select Page:

				<br/><select name="location" class="current">

					<option value="">Choose Category</option>

						<?php

							include 'includes/dbconnect.php';

							$sql="SELECT * FROM `tbl_corporate_cat`";

							$cont=mysql_query($sql) or die(mysql_error());

							while($con=mysql_fetch_array($cont)){

							$loc=$con['cat_name'];

							$id = $con['inc_cat_id'];

							if($id==$location){

						?>

					<option  value="<?php echo $id;?>" selected><?php echo $loc;?></option>

						<?php

							}//if

							else

							{

						?>

					<option  value="<?php echo $id;?>"><?php echo $loc;?></option>

						<?php

							}//else

							}//while

						?>

				</select>

				<input type="submit" value="Submit" name="submit">

				</form>

				<br/>

				<div id='success'>

					<?php

					parse_str($_SERVER['QUERY_STRING']);

					if(isset($success))

					if($success == 'suc'){

					?>

					<?php

					}

					if(isset($success))

					if($success == 'add'){

					?>

					<?php echo "<br/><br/><br/>Added image successfully.";?>

					<?php 

						}

					?>

				</div>

				<?php 	
					$suc='Successfully deleted image';
					$f = 'Image not deleted';
					if(isset($success))
					if($success == 'suc'){
						echo "<div class='error'>".$suc."</div>";
					}
					if(isset($fail))
					if($fail == 'f'){
						echo "<div class='error'>".$f."</div>";
					}
				?>

				<?php 
				$s='Updated home page courses content successfully.';
					if(isset($success))
					if($success == 's'){
							echo "<div class='error'>".$s."</div>";
					}
				if(isset($_GET['submit']) == ''){?>

				

				<h4>Images</h4>

        <table class="listing" cellpadding="0" cellspacing="0">

                        <tr>

							<th>S.NO</th>

							<th>Images</th>

                          	<th>Delete</th>

                        </tr>

		<?php	

				$sql2="SELECT * FROM `gallery`";

				$page2=mysql_query($sql2) or die(mysql_error());

				$rows1=mysql_num_rows($page2);

				$sno=0;

				while($img=mysql_fetch_array($page2)){

				$sno++;		

				$path=$img['path'];

				$id=$img['image_id'];

				$name=$img['name'];							

	?>

		<tr>

			<td><?php echo $sno;?></td>

			<td><img src="<?php echo $path;?>" alt="<?php echo $path;?>" width="30" height="30"></td>

			<td>

			<form method="post" action="" >

             <input type="hidden"  name="id" value="<?php echo $id ?>" /><input name="delete" title="delete" type="submit"   value="Delete"   >

         </form> 

			</td>

			</td>

	</tr>

	

	<?php

	}?>

</table>			

<?php	}

				if(isset($_GET['submit'])){?>

					<table class="listing" cellpadding="0" cellspacing="0">

						<tr>

					     	<th>Category</th>

							<th>Image</th>

						    <th>Delete </th>

						</tr>

					<?php  

							if($location=='Choose Page'){

							echo "<b style='color:red;font-size:14px'>please select atleast one page.</b>";

						}

						else{

							$id=$_REQUEST['location'];

							include 'includes/dbconnect.php';

							$sql="SELECT * FROM `gallery` Where `location`='$id' ORDER BY   `image_id` ASC";

							$images=mysql_query($sql) or die(mysql_error());

							$count=mysql_num_rows($images);

							if($count!=0){

								echo '<div id="heading"><span>'.$location. ' page images.</span></div>';							

                                 $sno=1;

								while($image=mysql_fetch_array($images)){

									$id=$image['image_id'];

									$sno

									?>

									<tr>										

										<td>

											<?php echo  $sno;?>

										</td>

										<td>

											<img src="<?php echo $image['path'];?>" width="40" height="40" alt=""/>

										</td>

					<td>

			<form method="post" action="" >

             <input type="hidden"  name="id" value="<?php echo $id ?>" /><input name="delete" title="delete" type="submit"   value="Delete"   >

         </form> 

			</td>

									</tr>

									<?php

									$sno++;

									}//while close

							}//if count close

								}//first if else close

					}//if submit close

					?>

					</table>

				</div><!--table-->

			</div><!--/center column-->

			<?php include 'includes/footer.php';?>

	</div><!--/main-->

	

	</body>

</html>

