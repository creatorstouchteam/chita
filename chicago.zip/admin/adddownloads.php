<!DOCTYPE html>
<?php 
if(isset($_POST['submit']))
{
	include 'includes/dbconnect.php';
	  $add=$_POST['add'];
     $con=$_POST['content'];
if(is_uploaded_file($_FILES["file"]["tmp_name"]))
{
	move_uploaded_file($_FILES["file"]["tmp_name"], "../img/" . $_FILES["file"]["name"]);
     $path=$_FILES["file"]["name"];
}
      $sql="insert into downloads(cat_name,path,cat_desc,dt_created) values('".$add."','".$path."','".$con."',current_date())";
     $result = mysql_query($sql);
}
?>
<html>
	<head>
		<title>Chicago Telangana Association - Admin</title>	
		<link href="img/icon.png" rel="icon">
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
		<script type="text/javascript" src="js/editor.js"></script>
		</head>
 <script type="text/javascript" language="javascript" >
			function validate()
			{
			 if (document.getElementById('add').value=="")
					   {    
						  alert("Enter name");
						  document.getElementById('add').focus();
						  return false;
					   }
			 if (document.getElementById('image').value=="")
					   {    
						  alert("Please Upload A file");
						  document.getElementById('image').focus();
						  return false;
					   }

			}
     </script>
	<body>
		<div id="main">
		<?php 
		$page="downloads";
		include 'includes/header.php';//header
		include 'includes/sidebar.php';//header
		parse_str($_SERVER['QUERY_STRING']);
		error_reporting(E_ALL ^ E_NOTICE);
		?>
		<div id="center-column">
		<form method="POST" action=""  enctype="multipart/form-data" onsubmit="return validate();">
				<div class="table">
				<div id="heading">
						<span>Add Latest News::</span>
				</div>
				<br/><br/><br/><br/>
				Add Name: <input type="text" name="add" id="add">
				<br/>
					<br/>
						<br/>
							Add File: <input type="file" name="file" id="file">
				<br/>
					<br/>
						<br/>
				<div id="bg">
						<center>
							<textarea id="elm1" name="content" rows="40" cols="80" style="width: 80%">
								
							</textarea>
						<br />
									
							<input type="submit" name="submit"  value="Submit"/>
							<input type="reset" name="reset" value="Reset" />
						</center>
						</div><!--/bg-->
					</form>
				<script type="text/javascript">
				if (document.location.protocol == 'file:') {
				alert("The examples might not work properly on the local file system due to security settings in your browser. Please use a real webserver.");
				}
				</script>
				</div><!--/table-->
			</div><!--/center column-->
		   <?php include 'includes/footer.php';?>
     </div><!--/main-->
	</body>
</html>