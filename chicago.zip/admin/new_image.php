<!DOCTYPE html>
 <?php include 'verification.php';?>

<?php
function getExtension($str) {
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
 }
$name=$content=$title=$titleerr=$linkerr=$link='';
$contenterr=$imageerr=$typeerr=$type='';
$photo='';
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		 $tmp=$_FILES["photo"]["tmp_name"];
		 $photo = $_FILES["photo"]["name"];
		 $path="img/".$photo;
		if (empty($_POST["title"])) {
						$titleerr = "Please enter your title";
					}
					else {
						$title = $_POST["title"];
					}
		if (empty($_POST["link"])) {
						$linkerr = "Please Select category.";
					}
					else {
						$link = $_POST["link"];
					}
  $type=getExtension($photo);
    if(empty($photo)){
			$imageerr="Please upload image";
		}
		else{
			if($type=='png' || $type=='jpg' || $type=='gif' || $type=='jpeg'){
			}
			else{
				$typeerr="png,gif,jpg,jpeg image extensions only.";
			}
		}
 if(!empty($photo)){
							list($width,$height)=getimagesize($tmp);
	 						 move_uploaded_file($tmp,"img/" . $photo);
							  include 'includes/dbconnect.php';
							  $query="select * from `images` WHERE `location`='Home'";
								$count=mysql_query($query);
								$row=mysql_num_rows($count);
							 $sql="INSERT INTO `gallery`(`name`, `path`, `location`) VALUES ('$title','$photo','$link')";
							mysql_query($sql);
							header('location:images.php?success=add');
						 }
	 }
?>
<html>
<head>
<title>Welcome to Chicago Telangana Association - Admin</title>
<link type="text/css" rel="stylesheet" href="css/admin.css"/>
</head>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    <link  href="css/admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="main">
	<?php 
	$page="Images";
		include 'includes/header.php';//header
		include 'includes/sidebar.php';//leftsidebar?>
	<div id="center-column">
			 <div class="table">
			 	<div id="heading">
						<span>New Home Page Image.</span>
				</div>
				<br/><br/><br/><br/>
			 <form action="" name="newimage" method="post" enctype="multipart/form-data" >
				 <div id="success">
					<?php if(isset($success)) echo $success; ?>
				 </div>
                    <table class="listing" cellpadding="0" cellspacing="0">
						<tr>
							<td >Title :</td>
							<td style="text-align:left"><input type="text" size="" name="title" value="<?php echo $title;?>"></td>
						</tr>
						<tr>
							<td colspan="2" ><span class="error"><?php echo $titleerr;?></span></td>
						</tr>
						<tr>
							<td >Image:</td>
							<td style="text-align:left"><input type="file" name="photo" id="photo" value=""></td>
						</tr>
						<tr>
							<td colspan="2" ><span class="error"><?php echo $imageerr;?></span>
							<span class="error"><?php echo $typeerr;?></span></td>
						</tr>						
						<tr>
							<td >Select Category:</td>
							<td style="text-align:left"><select  name="link">
							<option value="">Choose Category</option>
												<?php
							include 'includes/dbconnect.php';
							$sql="SELECT * FROM `tbl_catinfra`";
							$cont=mysql_query($sql) or die(mysql_error());
							while($con=mysql_fetch_array($cont)){
							$loc=$con['cat_name'];
							$id = $con['inc_cat_id'];
							if($id==$location){
						?>
					<option  value="<?php echo $id;?>" selected><?php echo $loc;?></option>
						<?php
							}//if
							else
							{
						?>
					<option  value="<?php echo $id;?>"><?php echo $loc;?></option>
						<?php
							}//else
							}//while
						?>
							</select>
							</td>
						</tr>
						<tr>
							<td colspan="2" ><span class="error"><?php echo $linkerr?></span></td>
						</tr>
						<tr>
							<td></td>
							<td style="text-align:left;"><input type="submit" name="submit" value="Submit" class="submit"></td>
						</tr>
					</table>
</form>

</div><!--table-->
         </div><!--/center column-->
           <!--quick info-->
     </div><!--main-->
     <?php include 'includes/footer.php';?>
</body>
</html>