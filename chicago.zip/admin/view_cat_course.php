<!DOCTYPE html>
 <?php
 include 'includes/dbconnect.php';
if(isset($_POST['deletesubmit']))
{
$id=$_POST['id'];
$ds="DELETE FROM tbl_cat_course WHERE inc_cat_id='$id'";
$rr=mysql_query($ds);
if($rr)
{
$err="<b><font color='green'>success fully Deleteded</b></font>";
}
}
?>
<html>
	<head>
		<title>Welcome to Chicago Telangana Association - Admin</title>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
		<script type="text/javascript" src="js/editor.js"></script>
	</head>
	<body>
		<div id="main">
		<?php
		$page="Pages";
		$locname='';
		include 'includes/header.php';//header
		include'includes/sidebar.php';
		parse_str($_SERVER['QUERY_STRING']);
		error_reporting(E_ALL ^ E_NOTICE);
		?>
		<div id="center-column">
						<div class="top-bar">
					<a href="aboutus.php" class="button">Add new About us</a><br/>
					<br/><br/>
				</div>
		<form method="POST" action="">
				<div class="table">
				<div id="heading">
						<span>List of About us ::</span>
				</div>
				<br/><br/><br/><br/>
			<div id="bg">
					 <table class="listing" cellpadding="0" cellspacing="0">
                        <tr>
							<th>Id</th>
							<th>Tittle</th>
							<th>Delete</th>
							<th>Edit</th>
                        </tr>
            <?php
				include 'includes/dbconnect.php';
				$sql2="SELECT * FROM `tbl_cat_course`";					
				$cont2=mysql_query($sql2) ;	
				$sno=1;
				while($row=mysql_fetch_array($cont2))				
          {?>
	<tr>
			<td><?php echo $sno++;?></td>
			<td><?php echo $row['cat_name'];?></td>
		<td>
			<form method="post" action="" >
             <input type="hidden"  name="id" value="<?php echo $row['inc_cat_id']; ?>" /><input name="deletesubmit" title="delete" type="submit"   value="Delete"   >
         </form> 
			</td>
		<td>
			<form method="get" action="page_modification.php" >
             <input type="hidden"  name="id" value="<?php echo $row['inc_cat_id']; ?>" /><input name="edit" title="edit" type="submit"   value="edit"   >
         </form>  
			</td>
		</tr>
 <?php }?>		
			
						</table>
						</div--><!--/bg-->
					</form>
				<script type="text/javascript">
				if (document.location.protocol == 'file:') {
				alert("The examples might not work properly on the local file system due to security settings in your browser. Please use a real webserver.");
				}
				</script>
				</div><!--/table-->
			</div><!--/center column-->
			</div>
			    <?php include 'includes/footer.php';?>
		</div><!--/main-->
	</body>
</html>