<?php include('verification.php');?>
 <?php
 include 'includes/dbconnect.php';
if(isset($_POST['delete']))
{
$id=$_POST['id'];
$ds="DELETE FROM companylogos WHERE image_id='$id'";
$rr=mysql_query($ds);
if($rr)
{
$err="<b><font color='green'>success fully Deleteded</b></font>";
}
}
?>
<?php
if(isset($_POST['submit'])){
		function getExtension($str) {
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
 }
$name=$content=$title=$titleerr=$linkerr=$link='';
$contenterr=$imageerr=$typeerr=$type='';
$photo='';
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		 $tmp=$_FILES["photo"]["tmp_name"];
		 $photo = $_FILES["photo"]["name"];
		 $path="pdf/".$photo;
		 //$con=trim($_POST["content"]);
		if (empty($_POST["link"])) {
						$linkerr = "Please enter link.";
					}
					else {
						$link = $_POST["link"];
					}
		$type=getExtension($photo);
		if(empty($photo)){
			$imageerr="Please upload image";
		}
		else{
			if($type=='png' || $type=='jpg' || $type=='gif' || $type=='jpeg'){
			}
			else{
				$typeerr="png,gif,jpg,jpeg image extensions only.";
			}
		}
	 if(!empty($photo)){
							list($width,$height)=getimagesize($tmp);
	 						 move_uploaded_file($tmp,"../pdf/" . $photo);
							  include 'includes/dbconnect.php';
							  $sql="INSERT INTO `companylogos`(`name`,`width`, `height`, `title`, `link`, `path`, `type`, `content`, `location`) VALUES ('$photo',$width,$height,'$title','$link','$path','$type','$content','1')";
							mysql_query($sql);
							///header('location:images.php?success=add');
							 $success="Images sucess fully upload.";
						 }
	 if(empty($titleerr)&&empty($linkerr)&&empty($contenterr)){
					 $title='';
					 $link='';
					 $content='';
				 }
}
}
?>
<!DOCTYPE html>
<html>
	<head>
   <title>Welcome to Chicago Telangana Association - Admin </title>
	<link href="img/icon.png" rel="icon">
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link  href="css/admin.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
	<div id="main">
		<?php
$page="1";
include 'includes/header.php';
	include 'includes/sidebar.php';
		?>
			<div id="center-column">
       
			 <form action="" name="newimage" method="post" enctype="multipart/form-data" >
				 <div id="success">
					<?php if(isset($success)) echo $success; ?>
				 </div>
                    <table class="listing" cellpadding="0" cellspacing="0">
						<tr>
							<td >Image:</td>
							<td style="text-align:left"><input type="file" name="photo" id="photo" value=""></td>
						</tr>
				<tr>
							<td></td>
							<td style="text-align:left;"><input type="submit" name="submit" value="Submit" class="submit"></td>
						</tr>
					</table>
</form>
				<div class="table">
				<div id="heading">
						<span>Images</span>
				</div>
				<?php
					$url=$_SERVER['QUERY_STRING'];
					parse_str($url);
				?>
						<div id='success'>
					<?php
					parse_str($_SERVER['QUERY_STRING']);
					if(isset($success))
					if($success == 'suc'){
					?>
					<?php echo "Updated image successfully.";?>
					<?php 
					}
					if(isset($success))
					if($success == 'add'){
					?>
					<?php echo "<br/><br/><br/>Added image successfully";?>
					<?php 
						}
					?>
				</div>
				<?php 	
					$suc='Successfully deleted image';
					$f = 'Image not deleted';
					if(isset($success))
					if($success == 'suc'){
						echo "<div class='error'>".$suc."</div>";
					}
					if(isset($fail))
					if($fail == 'f'){
						echo "<div class='error'>".$f."</div>";
					}
				?>
				<?php 
				$s='Updated home page courses content successfully.';
					if(isset($success))
					if($success == 's'){
							echo "<div class='error'>".$s."</div>";
					}
				if(isset($_GET['submit']) == ''){?>
				
				<h4>Images</h4>
        <table class="listing" cellpadding="0" cellspacing="0">
                        <tr>
							<th>S.NO</th>
							<th>Name</th>
                            <th>Delete</th>
                        </tr>
		<?php 	
				$sql2="SELECT * FROM `companylogos` ORDER BY  `image_id` DESC ";
				$page2=mysql_query($sql2) or die(mysql_error());
				$rows1=mysql_num_rows($page2);
				$sno=0;
				while($img=mysql_fetch_array($page2)){
				$sno++;		
				$path=$img['path'];
				$id=$img['image_id'];
				$name=$img['name'];							
	?>
		<tr>
			<td><?php echo $sno;?></td>
			<td><img src="../<?php echo $path;?>" alt="<?php echo $path;?>" width="30" height="30"></td>
				<td>
			<form method="post" action="" >
             <input type="hidden"  name="id" value="<?php echo $id?>" /><input name="delete" title="delete" type="submit"   value="Delete"   >
         </form> 
			</td>
			</td>
	</tr>
	
	<?php
	}?>
</table>			
<?php	}
				if(isset($_GET['submit'])){?>
					<table class="listing" cellpadding="0" cellspacing="0">
						<tr>
							<th>Name</th>
							<th>Content</th>
							<th>Image Type</th>
							<th>Width</th>
							<th>Height</th>
							<th>Location</th>
							<th>Image</th>
							<th> Edit</th>
							<th>Delete </th>
						</tr>
					<?php 
							if($location=='Choose Page'){
							echo "<b style='color:red;font-size:14px'>please select atleast one page.</b>";
						}
						else{
							include 'includes/dbconnect.php';
							$sql="SELECT * FROM `companylogos` Where `location`='$location' ORDER BY   `image_id` ASC";
							$images=mysql_query($sql) or die(mysql_error());
							$count=mysql_num_rows($images);
							if($count!=0){
								echo '<div id="heading"><span>'.$location. ' page images.</span></div>';
								$sno=1;
								while($image=mysql_fetch_array($images)){
									$id=$image['image_id'];
									?>
									<tr>
										<td>
											<?php echo $image['name'];?>
										</td>
										<td align="justify">
											<?php echo $image['content'];?>
										</td>
										<td>
											<?php echo $image['type'];?>
										</td>
										<td>
											<?php echo $image['width'];?>
										</td>
										<td>
											<?php echo $image['height']?>
										</td>
										<td>
											<?php echo $image['location'];?>
										</td>
										<td>
											<img src="<?php echo '../'.$image['path']?>" width="40" height="40" alt="<?php echo $name?>"/>
										</td>
									<?php if($location=='Home'){
										$link='image_modification.php';?>
										<td>
											<a href="<?php echo $link?>?id=<?php echo $id?>&edit=modify"><img src="img/edit-icon.gif" width="16" height="16" alt="" /></a> 
										</td>
									<?php }
										else{
										$link='other_image_modification.php';?>
										<td>
											<a href="<?php echo $link?>?id=<?php echo $id?>&edit=modify"><img src="img/edit-icon.gif" width="16" height="16" alt="" /></a> 
										</td>
									<?php }?>
										<td>
											<a href="image_modification.php?name=<?php echo $image['name']?>&delete=remove" onClick="return confirm('Are You Sure Want Delete');"><img src="img/hr.gif" width="16" height="16" alt="add" /></a>
										</td>
									</tr>
									<?php 
									$sno++;
									}//while close
							}//if count close
							else{
								echo "<b style='color:red;font-size:14px'>There are not available any images.</b>";
							}//else close
						}//first if else close
					}//if submit close
					?>
					</table>
				</div><!--table-->
			</div><!--/center column-->
			<?php include 'includes/footer.php';?>
	</div><!--/main-->	
	</body>
</html>