<?php include('verification.php');
if($_SERVER['REQUEST_METHOD']=='POST'){
		$currentpassword=$_POST['currentpassword'];
		$newpassword=$_POST['newpassword'];
		$confirmpassword=$_POST['confirmpassword'];
		include 'includes/dbconnect.php';
		$sql="SELECT * FROM `admin_register` WHERE `username`='$login_session'";
		$result=mysql_query($sql) or die(mysql_error());
		$rows=mysql_num_rows($result);
		$fetch=mysql_fetch_array($result);
		$current=$fetch['password'];
		md5($currentpassword);
			
			if($newpassword != $confirmpassword){
						$match="Password and confirm password doesn't match.";
			}
			if($currentpassword==''){
					$cur="Required field cannot be left blank.";
			}
			else{
				if(md5($currentpassword)!= $current){
				$error="The password you gave is incorrect.";
				}
			}
			if($newpassword==''){
					$n="Required field cannot be left blank.";
								
			}
			if($confirmpassword == ''){
						$c="Required field cannot be left blank.";
			}

			if(empty($match)&&empty($error)&&empty($cur)&&empty($c)&&empty($n)){
				$pwd=md5($newpassword);
				$query="UPDATE `admin_register` SET  `password`='$pwd' WHERE  `username`='$login_session';";
				mysql_query($query);
				$success="Password Successfully changed.";
			}
	
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Palanadu Educational Society-admin </title>
	    <link href="img/icon.png" rel="icon">
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link  href="css/admin.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
	<div id="main">
		<?php 
		$page="Change Password";
		include 'includes/header.php';//header
		include 'includes/sidebar.php';//leftsidebar
		?>
			<div id="center-column">
				<div id="success">
					<?php if(isset($success)) echo $success; ?>
				 </div>
				<div class="table">
					<h1>Change Password</h1>
					<p>To reset your password, provide your current password.</p>
					<p><span style="color:#0c4f88;font-weight:bold;">Note</span>: you can't reuse your old password once you change it!</p>
					<form method="post" action="">
					<table class="listing" cellpadding="0" cellspacing="0">
						<tr>
							<td style="text-align:right">Current Password<span style="color:red">*</span>:</td>
							<td style="text-align:left"><input type="password" name="currentpassword" value=""></td>
						</tr>
						<tr>
							<td colspan="2">
								<span class="error"><?if(isset($cur)) echo $cur;?></span>
								<span class="error"><?if(isset($error)) echo $error;?></span>
							</td>
						</tr>
						<tr>
							<td style="text-align:right">New Password<span style="color:red">*</span>:</td>
							<td style="text-align:left"><input type="password" name="newpassword" value=""></td>
						</tr>
						<tr>
							<td colspan="2"><span class="error"><?if(isset($n)) echo $n;?></span></td>
						</tr>
						<tr>
							<td style="text-align:right">Confirm Password<span style="color:red">*</span>:</td>
							<td style="text-align:left"><input type="password" name="confirmpassword" value=""></td>
						</tr>
						<tr>
							<td colspan="2"><span class="error"><?php if(isset($c)) echo $c;?></span>
											<span class="error"><?php if(isset($match)) echo $match;?></span>
							</td>
						</tr>
						<tr>
							<td style="text-align:center" colspan="2"><input type="submit" name="submit" value="Save"  class="submit">
								<input type="reset" name="reset" value="Cancel"  class="submit"></td>
						</tr>
					</table>
					</form>
				</div><!--table-->
			</div><!--/center column-->
				<?php include 'includes/footer.php';?>
	</div><!--/main-->
	</body>
</html>