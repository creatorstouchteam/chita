<!DOCTYPE html>
<?php 
error_reporting(0);
if(isset($_POST['submit']))
{
	include 'includes/dbconnect.php';
	 $name=$_POST['name'];
	 $id=$_REQUEST['id'];
	     $sql="UPDATE `timetable_cat` SET `cat_name`='".$name."' WHERE `inc_cat_id`='$id';";
	     $result = mysql_query($sql);
        echo "<script>alert('update succefully');
						window.location = 'view_timetable_cat.php';
					</script>";
}
?>
<html>
	<head>
	<title>Chicago Telangana Association - Admin</title>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		</head>
<script type="text/javascript" language="javascript" >
function validate()
{
 if (document.getElementById('name').value=="")
           {    
		      alert("Enter Category name");
              document.getElementById('name').focus();
              return false;
           }
}
</script>    
	<body>
	<?php 
	include 'includes/dbconnect.php';
					$id=$_REQUEST['id'];
					$sql2="SELECT * FROM `timetable_cat` where inc_cat_id='$id'";					
					   $cont2=mysql_query($sql2) ;	
					   $row=mysql_fetch_array($cont2);
					   $title=$row['cat_name'];
	?>
		<div id="main">
		<?php 
			include 'includes/header.php';//header
            include 'includes/sidebar.php';
		parse_str($_SERVER['QUERY_STRING']);
		error_reporting(E_ALL ^ E_NOTICE);
		?>
	<div id="admin1">
		<form method="POST" action=""  enctype="multipart/form-data" onsubmit="return validate();">
				<span>Edit Time Table Category:</span>
				<table>
				<tr><td>Catgorey Name:</td><td><input type="text" name="name" value="<?php echo $title;?>"size="45" id="name"></td></tr>
				<tr><td></td><td colspan="2"><input name="submit" type="submit" value="update" id="butSubmit"></td></tr>
				</table>
		</form>
		</div><!--/center column-->
		   <?php include 'includes/footer.php';?>
     </div><!--/main-->
	</body>
</html>