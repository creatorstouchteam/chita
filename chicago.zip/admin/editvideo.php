<?php 

error_reporting(0);

if(isset($_POST['submit']))

{

	include 'includes/dbconnect.php';

$id=$_REQUEST['id'];

 $name= $_POST['name'];

  $url=$_POST['url'];

    $con=$_POST['content'];



 echo $sql="UPDATE `tbl_videos` SET `video_title`='$name',`video`='$con',`vedio_url`='$url' WHERE `video_inc_id`='$id'";

						mysql_query($sql);

						header("location:viewVideo.php");

}

?>

<!DOCTYPE html>

<html>

	<head>

<title>Welcome to Chicago Telangana Association - Admin</title>

		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />

		<link type="text/css" rel="stylesheet" href="css/admin.css"/>

		</head>

<script type="text/javascript" language="javascript" >

function validate()

{

 if (document.getElementById('name').value=="")

           {    

		      alert("Enter Category name");

              document.getElementById('name').focus();

              return false;

           }

}

</script>    

	<body>

	<div id="main">

		<?php 

		include 'includes/header.php';//header

	    include 'includes/sidebar.php';

	?>

	<?php

					include 'includes/dbconnect.php';

					$id=$_REQUEST['id'];

			           $sql2="SELECT *FROM  `tbl_videos` WHERE  `video_inc_id` ='$id'";					

					   $cont2=mysql_query($sql2) ;	

					   $row=mysql_fetch_array($cont2);

					   $title=$row['video_title'];

					   $dec=$row['vedio_url'];

?>

	<div id="admin1">

		<form method="POST" action=""  enctype="multipart/form-data" onsubmit="return validate();">

				<span>Edit Videos:</span>

						<table>

				<tr><td>Video tittle:</td><td><input type="text" name="name" value="<?php echo $title;?>" id="add" size="45"></td></tr>

				<tr>

				<td>Url</td><td><input type="text" name="url" id="url" size="45"  value="<?php echo $dec?>"></td>

				</tr>

				<tr><td></td><td colspan="2"><input type="submit" name="submit" value="submit"></td></tr>

				</table>

		</form>

		</div><!--/center column-->

		   <?php include 'includes/footer.php';?>

     </div><!--/main-->

	</body>

</html>