 <?php include'verification.php';?>
<!DOCTYPE html><head>
 <title>Welcome to Chicago Telangana Association - Admin </title>
<link type="text/css" rel="stylesheet" href="css/admin.css"/>
</head>
    
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    <link  href="css/admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="main">	
	<?php
	    $page='Home';
		include 'includes/header.php';//header
			include 'includes/sidebar.php';
		?>
	<div id="center-column">
			<div id="heading">
					<span>Welcome <?php echo $login_session; ?></span>
			</div>
			<br/><br/>
				 <div class="table">
                    
				 </div>
                 <!--table-->
         </div><!--/center column-->
           <!--quick info-->
		<?php include 'includes/footer.php';?> 
     </div><!--main-->     
</body>
</html>