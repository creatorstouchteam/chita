<!DOCTYPE html>
 <?php include('verification.php');
 error_reporting(E_ALL ^ E_NOTICE);
?>
<html>
<head>
<title>Chicago Telangana Association - Admin</title>
<link type="text/css" rel="stylesheet" href="css/admin.css"/>
</head>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    <link  href="css/admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="main">
<?php 	$page="Slides";
		include 'includes/header.php';//header
		include 'includes/sidebar.php';//leftsidebar?>
	<div id="center-column">
		
		 <div class="table">
                    <table class="listing" cellpadding="0" cellspacing="0">
                       <?php  
$data=$_SERVER["QUERY_STRING"];
parse_str($data);
$modify="modify";
$remove="remove";

if ($modify == isset($edit)) {
		function getExtension($str) {
				 $i = strrpos($str,".");
				 if (!$i) { return ""; }
				 $l = strlen($str) - $i;
				 $ext = substr($str,$i+1,$l);
				 return $ext;
		 }
$photo=$error=$error1=$titleerr=$contenterr=$success='';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$name = $_FILES["photo"]["name"];
			$tmp=$_FILES["photo"]["tmp_name"];
			$type =getExtension($name);
			$path="images/".$name;
			$title = $_POST['title'];
			$content = $_POST['content'];
			if($name==''){
							 $error1="Please choose Image.";
						 }//if name close
			if($content == ''){
				$contenterror = "Please provide content.";
			}
			 if($error1 == '' && $contenterror == ''){
					 if($type=='png' || $type=='jpg' || $type=='gif'|| $type='jpeg'){
							list($width,$height)=getimagesize($tmp);
							move_uploaded_file($tmp,"../images/" . $name);
							include 'includes/dbconnect.php';
							$sql="UPDATE  slides SET width='$width',height='$height', name='$name',path='$path',type='$type',content = '$content',title = '$title' WHERE slide_id='$id'";
						mysql_query($sql)or die('Could not connect: ' . mysql_error());
							 header('location:slides.php?success=suc');
						}//if type of image close
					else{				
							$error="png,jpg,jpeg,gif images extensions only.";
						 }//else close
				}//else close
		}//if post close
		?>


<div id="content">
<br/>
<?php 

include 'includes/dbconnect.php';
$sql="SELECT * FROM  slides where slide_id='$id'";
					 $images=mysql_query($sql) or die(mysql_error());
	while($image=mysql_fetch_array($images)){
					
		?>
<form name="form" method="post" action="" enctype="multipart/form-data" >
<h1>Update Slide</h1>
<table id="images" width="900px">
	<tr>
		<td align="right">Image:</td>
		<td id="error">
		<input type="file" name="photo" id="photo" value="">
		<span class="error"><?php echo $error;?></span>
		<span class="error"><?php echo $error1;?></span>
		</td>
	</tr>
	<tr>
		<td align="right">Title:</td>
		<td id="error">
		<input type="text" name="title" id="title" value="">
     	</td>
	</tr>
	<tr>
		<td>Content</td>
		<td style="text-align:left">
		<textarea name="content" rows="10" cols="25"  maxlength="950">

		</textarea>	
		<span class="error"><?php echo $contenterror;?></span>
		</td>
	</tr>

	<tr>
		<td></td>
		<td><input type="submit" name="submit" value="Submit" ></td>
	</tr>
</table>
</form>
<?php 
}
}
?>
</div><!--content close-->
<?php if($remove=isset($delete)){
	$suc="Successfully deleted image";
	$fail="Image not deleted";
?>
	<div id="content">
		<div id="success">
			<?php 
			 $sql="DELETE FROM  slides WHERE slide_id='$id'";
			 $del=mysql_query($sql) or die(mysql_error());
			 if($del==1){
				 header('location:slides.php?success=suc');
			}
			 else{
				 header('location:slides.php?fail=f');
			}
			?>
		</div>
	</div>
<?php 
}
?>
</table>

</div><!--table-->
         </div><!--/center column-->
           <!--quick info-->
     </div><!--spacing-->
     <?php include 'includes/footer.php';?>
</body>
</html>