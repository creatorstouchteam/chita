<!DOCTYPE html>
 <?php 
if(isset($_POST['submit'])){
include 'includes/dbconnect.php';
$select=$_POST['select'];
$name= $_POST['name'];


$con= $_POST['content'];
if(is_uploaded_file($_FILES["file"]["tmp_name"]))
{
	move_uploaded_file($_FILES["file"]["tmp_name"], "../img/" . $_FILES["file"]["name"]);
				$path=$_FILES["file"]["name"];
}
if($name!=""){
	$id=$_REQUEST['id'];
$sql="UPDATE `library_faculty` SET `fac_id`='$select',`faculty_img`='$path',`faculty_name`='$name',`faculty_desig`='$con' WHERE `inc_id`='$id'";
$rns=mysql_query($sql);	
echo "<script>alert('update succefully');
						window.location = 'viewFaculty_library.php';
					</script>";
}
}
?>
<html>
<head>
		<title>Welcome to Chicago Telangana Association - Admin</title>
		<link href="img/icon.png" rel="icon">
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
		<script type="text/javascript" src="js/editor.js"></script>
		</head>		
 <script type="text/javascript" language="javascript" >
			function validate()
			{
			 if (document.getElementById('add').value=="")
					   {    
						  alert("Enter name");
						  document.getElementById('add').focus();
						  return false;
					   }
				 if (document.getElementById('elm1').value=="")
					   {    
						  alert("Enter Content");
						  document.getElementById('elm1').focus();
						  return false;
					   }
			}
     </script>
<body>
		<div id="main">
		<?php
		$page="faculty";
		 include 'includes/header.php';//header
		 	include 'includes/sidebar.php';
	?>
	<?php
					include 'includes/dbconnect.php';
				    	$id=$_REQUEST['id'];
					   $sql2="SELECT * FROM `library_faculty` where inc_id='$id'";					
					   $cont2=mysql_query($sql2) ;	
					   $row=mysql_fetch_array($cont2);
					   $name=$row['faculty_name'];
					   $path=$row['faculty_img'];
					   $dec=$row['faculty_desig'];
					   
					   
?><?php 
						if(isset($_POST['Update'])){
					$con=$_POST['content'];	
					$name=$_POST['name'];		
						if(is_uploaded_file($_FILES["image"]["tmp_name"]))
						{
						move_uploaded_file($_FILES["image"]["tmp_name"], "../img/" . $_FILES["image"]["name"]);
					 $path=$_FILES["image"]["name"];
						include 'includes/dbconnect.php';
					$update="UPDATE `library_faculty` SET `faculty_name`='".$name."',`faculty_desig`='".$con."',`faculty_img`='".$path."' WHERE `inc_cat_id`='$id'";
						mysql_query($update);
						echo "<script>alert('update succefully');
						window.location = 'viewFaculty_library.php';
					</script>";
						}else{
					include 'includes/dbconnect.php';
					$update="UPDATE `library_faculty` SET `faculty_name`='".$name."',`faculty_desig`='".$con."',`faculty_img`='".$path."' WHERE `inc_cat_id`='$id'";
						mysql_query($update);
						echo "<script>alert('update succefully');
						window.location = 'viewFaculty_library .php';
					</script>";
					}
					}
				?>	
		<div id="center-column">
		 <form action=""  name="myForm" method="POST" enctype="multipart/form-data" onsubmit="return validate();">
		   <div class="table">
				<div id="heading">
						<span>Edit Library Staff</span>
				</div>
				<br/><br/><br/><br/>
		   <table>
			 <tr>

				<td>Select Catgorey:</td><td>

				  <select name="select" id="select">

				  <option value=" ">select catgorey</option>

				  <?php 

				  include 'includes/dbconnect.php';

				  $sql ="select * from library_fac_cat order by cat_name asc";

				  $cont2=mysql_query($sql) ;	

				  while($row=mysql_fetch_array($cont2))
				  
				  

				  {?>

				   <option value="<?php echo $row['inc_cat_id'];?>"><?php echo $row['cat_name'];?></option>

				  <?php }?>				 

				  </select>

				</td>			

				</tr>
			 <tr><td>Name:</td><td><input type="text" name="name" id="name" value="<?php echo $name;?>" size="45"></td></tr>
			 <tr><td>Picture:</td><td><input type="file" name="file" id="file"size="45"><a href="../img/<?php echo $path;?>"><img src="../images/Word_2013_Icon.png" width="30"></a> <?php echo $path;?></td></td></tr>
				
				
				<tr>
				<td>Description</td><td><textarea id="elm1" name="content" rows="10" cols="50"><?php echo $dec;?></textarea></td>
				</tr>
				<tr><td></td><td colspan="2"><input type="submit" name="submit" value="submit"></td></tr>
		   </table>
		  </form>
		  </div><!--/table-->
</div><!--/center column-->
		   <?php include 'includes/footer.php';?>
     </div><!--/main-->
</body>
</html>