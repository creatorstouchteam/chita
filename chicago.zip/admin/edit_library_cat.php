<!DOCTYPE html>
<?php 
error_reporting(0);
if(isset($_POST['submit']))
{
	include 'includes/dbconnect.php';
	 $name=$_POST['name'];
	 $id=$_REQUEST['id'];
	     $sql="UPDATE `library_fac_cat` SET `cat_name`='".$name."' WHERE `inc_cat_id`='$id';";
	     $result = mysql_query($sql);
        echo "<script>alert(' sucfully');</script>";
		header("location:view_library_cat.php");
		echo "<script>alert('Inserted sucfully');</script>";
}
?>
<html>
	<head>
	<title>Welcome to Chicago Telangana Association - Admin</title>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		</head>
<script type="text/javascript" language="javascript" >
function validate()
{
 if (document.getElementById('name').value=="")
           {    
		      alert("Enter Category name");
              document.getElementById('name').focus();
              return false;
           }
}
</script>    
	<body>
	<?php 
	include 'includes/dbconnect.php';
					$id=$_REQUEST['id'];
					$sql2="SELECT * FROM `library_fac_cat` where inc_cat_id='$id'";					
					   $cont2=mysql_query($sql2) ;	
					   $row=mysql_fetch_array($cont2);
					   $title=$row['cat_name'];
	?>
		<div id="main">
		<?php 
			include 'includes/header.php';//header
            include 'includes/sidebar.php';
		parse_str($_SERVER['QUERY_STRING']);
		error_reporting(E_ALL ^ E_NOTICE);
		?>
	<div id="admin1">
		<form method="POST" action=""  enctype="multipart/form-data" onsubmit="return validate();">
				<span>Edit Library Staff Category:</span>
				<table>
				<tr><td>Library Staff Category Name:</td><td><input type="text" name="name" value="<?php echo $title;?>"size="45" id="name"></td></tr>
				<tr><td></td><td colspan="2"><input name="submit" type="submit" value="update" id="butSubmit"></td></tr>
				</table>
		</form>
		</div><!--/center column-->
		   <?php include 'includes/footer.php';?>
     </div><!--/main-->
	</body>
</html>