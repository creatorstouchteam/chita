<!DOCTYPE html>

 <?php 

if(isset($_POST['submit'])){

include 'includes/dbconnect.php';

$select=$_POST['select'];

$name= $_POST['name'];

$con= $_POST['content'];

if(is_uploaded_file($_FILES["file"]["tmp_name"]))

{

	move_uploaded_file($_FILES["file"]["tmp_name"], "../img/" . $_FILES["file"]["name"]);

				$path=$_FILES["file"]["name"];

}

if($name!=""){

$sql="insert into 
physical_faculty(fac_id,faculty_name,faculty_img,`faculty_desig`,dt_created) values('".$select."','".$name."','$path', '".$con."',current_date())";

$rns=mysql_query($sql);	

if($rns)

  {

echo "<script>alert('Thanks for uploading file');</script>";

}

else{


header("location:viewFaculty_physical.php");
	
}

}

}

?>

<html>

	<head>
		<title>Welcome to Chicago Telangana Association - Admin</title>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
		<script type="text/javascript" src="js/editor.js"></script>
	</head>	

 <script type="text/javascript" language="javascript" >

function validate()

{

 if (document.getElementById('name').value=="")

           {    

		      alert("Enter your full name");

              document.getElementById('name').focus();

              return false;

           }

 //----file---

       if (document.getElementById('file').value=="")

           {    

		      alert("Please attach Files");

              document.getElementById('file').focus();

              return false;

           }

		   

		     var x = document.getElementById('file').value;

                      

           if (x.length < 4 )

           {

              

				 document.getElementById('file').focus();

                return false;

           }

   

   if (document.getElementById('design').value=="")

   {    

	  alert("Enter your full name");

	  document.getElementById('design').focus();

	  return false;

   }

if (document.getElementById('qul').value=="")

   {    

	  alert("Enter Qualfication");

	  document.getElementById('qul').focus();

	  return false;

   }		

}

</script>

	<body>

		<div id="main">

		<?php $page="Pages";

		$locname='';

		include 'includes/header.php';//header

		include 'includes/sidebar.php';//header

		parse_str($_SERVER['QUERY_STRING']);

		error_reporting(E_ALL ^ E_NOTICE);

		?>

		<div id="center-column">

		 <form action=""  name="myForm" method="POST" enctype="multipart/form-data" onsubmit="return validate();">

				<div class="table">

				<div id="heading">

						<span>Add Physical Education Faculty</span>

				</div>

				<br/><br/><br/><br/>

				<table>

				<tr>

				<td>Select Catgorey:</td><td>

				  <select name="select" id="select">

				  <option value=" ">select catgorey</option>

				  <?php 

				  include 'includes/dbconnect.php';

				  $sql ="select * from physical_fac_cat order by cat_name asc";

				  $cont2=mysql_query($sql) ;	

				  while($row=mysql_fetch_array($cont2))

				  {?>

				   <option value="<?php echo $row['inc_cat_id'];?>"><?php echo $row['cat_name'];?></option>

				  <?php }?>				 

				  </select>

				</td>			

				</tr>

				<tr><td>Name:</td><td><input type="text" name="name" id="name" size="45"></td></tr>

				<tr><td>Picture:</td><td><input type="file" name="file" id="file"size="45"></td></tr>

				<tr>

				<td>Mater:</td><td><textarea rows="10" cols="50" name="content" id="elm1" ></textarea></td>

				</tr>

				<tr><td></td><td colspan="2"><input type="submit" name="submit" value="submit"></td></tr>

				</table>

				</form>

			</div><!--/table-->

			</div><!--/center column-->

		   <?php include 'includes/footer.php';?>

     </div><!--/main-->

	</body>

</html>