<!DOCTYPE html>
<html>
	<head>
<title>Chicago Telangana Association - Admin</title>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
		<script type="text/javascript" src="js/editor.js"></script>
	</head>
	<script type="text/javascript" language="javascript" >
			function validate()
			{
			 if (document.getElementById('add').value=="")
					   {    
						  alert("Enter name");
						  document.getElementById('add').focus();
						  return false;
					   }
				 if (document.getElementById('elm1').value=="")
					   {    
						  alert("Enter Content");
						  document.getElementById('elm1').focus();
						  return false;
					   }
			}
     </script>
	<body>
		<div id="main">
		<?php
		$page="admissions";
		 include 'includes/header.php';//header
		 	include 'includes/sidebar.php';
	?>
		<div id="center-column">
		<form method="POST" action="" enctype="multipart/form-data" onsubmit="return validate();">
				<div class="table">
				<div id="heading">
						<span>Edit Latest News</span>
				</div>
				<br/><br/><br/><br/>
			<?php			
					include 'includes/dbconnect.php';
					$id=$_REQUEST['id'];
		$sql2="SELECT * FROM `admissions` WHERE inc_cat_id='$id'";					
					$cont2=mysql_query($sql2) or die(mysql_error($sql2));
					$con2=mysql_fetch_array($cont2);
				$content=$con2['cat_desc'];	
					$name=$con2['cat_name'];
                    $path=$con2['path'];
					?>
					<?php 
						if(isset($_POST['Update'])){
					$con=$_POST['content'];	
					$name=$_POST['name'];		
						if(is_uploaded_file($_FILES["image"]["tmp_name"]))
						{
						move_uploaded_file($_FILES["image"]["tmp_name"], "../img/" . $_FILES["image"]["name"]);
					 $path=$_FILES["image"]["name"];
						include 'includes/dbconnect.php';
					$update="UPDATE `admissions` SET `cat_name`='".$name."',`cat_desc`='".$con."',`path`='".$path."' WHERE `inc_cat_id`='$id'";
						mysql_query($update);
						echo "<script>alert('update succefully');
						window.location = 'view_news.php';
					</script>";
						}else{
					include 'includes/dbconnect.php';
					$update="UPDATE `admissions` SET `cat_name`='".$name."',`cat_desc`='".$con."' WHERE `inc_cat_id`='$id'";
						mysql_query($update);
						echo "<script>alert('update succefully');
						window.location = 'view_news.php';
					</script>";
					}
					}
				?>				
				<div id="bg">
				<table>
				<tr><td>Title:</td><td><input type="text" name="name" id="add" value="<?php echo $name;?>"></td></tr>
				<tr><td>Images:</td><td><input type="file" name="image"></td><td><img src="../img/<?php echo $path;?>" width="100" height="100"></td></tr>
					</table>
				
				</br></br>
						<center>
							<textarea id="elm1" name="content" rows="40" cols="80" style="width: 80%">
								<?php
								if(isset($content))	
								echo $content;								
								?>
							</textarea>
						<br />
						<?
							$length='';
							if(isset($content))	
								$length=strlen($content);
								if($length<300){
									$name="Submit";
								}
								else{
									$name="Update";
								}
						?>
						
							<input type="submit" name="Update"  value="update"/>
						</center>
						</div><!--/bg-->
					</form>
				<script type="text/javascript">
				if (document.location.protocol == 'file:') {
				alert("The examples might not work properly on the local file system due to security settings in your browser. Please use a real webserver.");
				}
				</script>
				</div><!--/table-->
			</div><!--/center column-->
			<?php include 'includes/footer.php';?>
		</div><!--/main-->
    	</body>
</html>