<?php
if($_POST['pgaction']=="upload")
	upload();
else
	uploadForm();
function uploadForm() {
?>

<html>

<head>

<title>Welcome to Chicago Telangana Association - Admin</title>

<link type="text/css" rel="stylesheet" href="css/admin.css"/>

</head>

    <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />

    <link  href="css/admin.css" rel="stylesheet" type="text/css" />

</head>

<body>

    <div id="main">

	<?php 
	$page="Images";
		include 'includes/header.php';//header
		include 'includes/sidebar.php';//leftsidebar?>
	<div id="center-column">
			 <div class="table">
			 	<div id="heading">
<form name="frm" method="post" onSubmit="return validate(this);" enctype="multipart/form-data">
<input type="hidden" name="pgaction">
	<?php if ($GLOBALS['msg']) { echo '<center><span class="err">'.$GLOBALS['msg'].'</span></center>'; }?>
	<table >	
				<tr>
							<td colspan="2" >Select Category:</td>
							<td style="text-align:left"><select  name="link">
							<option value="">Choose Category</option>
												<?php
							include 'includes/dbconnect.php';
							$sql="SELECT * FROM `tbl_corporate_cat`";
							$cont=mysql_query($sql) or die(mysql_error());
							while($con=mysql_fetch_array($cont)){
							$loc=$con['cat_name'];
							$id = $con['inc_cat_id'];
							if($id==$location){
						?>
					<option  value="<?php echo $id;?>" selected><?php echo $loc;?></option>
						<?php
							}//if
							else
							{
						?>
					<option  value="<?php echo $id;?>"><?php echo $loc;?></option>
						<?php
							}//else
							}//while
						?>
							</select>
							</td>
						</tr>
		<tr class="tblSubHead">
			<td colspan="2">Upload file</td>
				<td valign="top"><div id="dvFile"><input type="file" name="item_file[]"></div></td>
			<td valign="top"><a href="javascript:_add_more();" title="Add more"><img src="plus_icon.gif" border="0"></a></td>
		</tr>
		<tr>
			<td align="center" colspan="2"><input type="submit" value="Upload File"></td>
		</tr>
	</table>
</form>
<script language="javascript">
<!--
	function _add_more() {
		var txt = "<br><input type=\"file\" name=\"item_file[]\">";
		document.getElementById("dvFile").innerHTML += txt;
	}
	function validate(f){
		var chkFlg = false;
		for(var i=0; i < f.length; i++) {
			if(f.elements[i].type=="file" && f.elements[i].value != "") {
				chkFlg = true;
			}
		}
		if(!chkFlg) {
			alert('Please browse/choose at least one file');
			return false;
		}
		f.pgaction.value='upload';
		return true;
	}
//-->
</script>
</body>
</html>
<?php
}

//function to store uploaded file

function upload(){	
	if(count($_FILES["item_file"]['name'])>0) { //check if any file uploaded
		$GLOBALS['msg'] = ""; //initiate the global message
		for($j=0; $j < count($_FILES["item_file"]['name']); $j++) { //loop the uploaded file array
			$filen = $_FILES["item_file"]['name']["$j"]; //file name
			$path = 'img/'.$filen; //generate the destination path
			if(move_uploaded_file($_FILES["item_file"]['tmp_name']["$j"],$path)) { //upload the file
				$GLOBALS['msg'] .= ($j+1)." $filen uploaded successfully<br>"; //Success message
					include'includes/dbconnect.php';
			$link=$_POST['link'];
	$sql2="SELECT * FROM `tbl_corporate_cat` where inc_cat_id='$link'";					
					   $cont2=mysql_query($sql2) ;	
					   $row=mysql_fetch_array($cont2);
					   $title=$row['cat_name'];
                         $sql="INSERT INTO `gallery`(`path`,`location`,`name`) VALUES ('$path','$link','$title')";
			$rns=mysql_query($sql);	
			}
		}
	}
	else {
		$GLOBALS['msg'] = "No files found to upload"; //Failed message	
	}
	uploadForm(); //display the main form
}
?>