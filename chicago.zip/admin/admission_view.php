<?php include('verification.php');?>
<!DOCTYPE html>
<?php
 include 'include/dbconnect.php';
if(isset($_POST['deletesubmit']))
{
$id=$_POST['id'];
$ds="DELETE FROM admissiondetails WHERE inc_cat_id='$id'";
$rr=mysql_query($ds);
if($rr)
{
$err="<b><font color='green'>success fully Deleteded</b></font>";
}
}

?>
<html>
	<head>
		<title>Welcome to Chicago Telangana Association - Admin</title>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
		<script type="text/javascript" src="js/editor.js"></script>
	</head>
	<body>
		<div id="main">
		<?php
		$page="";
		$locname='';
		include 'includes/header.php';
			include 'includes/sidebar.php';
		?>
	<div id="center-column">
		<div class="top-bar floatleft">
		<div id="heading">
						<span>Admission Registration List ::</span>
				</div>
		<br/><br/>
	</div>
		<div id="center-column">
        
        
<form method="post">	
   <table width="100%" border="1" cellpadding="5px">
    
	 
				
	   
    <tr style="font-weight:bold;">
	
<td>S.No  :</td>




<td>Name :</td>





<td>Mobile Number :</td>




<td>Email ID :</td>





</tr>
          
   		<?php
				include 'includes/dbconnect.php';
				$sql2="SELECT * FROM `admissiondetails`";					
				$cont2=mysql_query($sql2) ;	
				while($row=mysql_fetch_array($cont2))				
          {?>      
<tr>

<td><?=$row['id']?></td>


<td><?=$row['name']?></td>



<td><?=$row['mobile']?></td>



<td><?=$row['email']?></td>


</tr>

<?php } ?>
     
  
</table>
	  </form>
        
        </div><!--/table-->
        
			</div><!--/center column-->
			</div>
			    <?php include 'includes/footer.php';?>
		</div><!--/main-->
	</body>
</html>