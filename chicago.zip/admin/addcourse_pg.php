<!DOCTYPE html>
<?php 
if(isset($_POST['submit']))
{
	if(is_uploaded_file($_FILES["image"]["tmp_name"]))
{
	move_uploaded_file($_FILES["image"]["tmp_name"], "../pdf/" . $_FILES["image"]["name"]);
	$path=$_FILES["image"]["name"];
}
	include 'includes/dbconnect.php';
	 $name=$_POST['name'];
	 $con=$_POST['content'];
	     $sql="select * from courses_pg where cat_name='".$name."'";
         $result = mysql_query($sql);
	     $query=mysql_num_rows($result);
      if($query!=0)
	    {
         echo "<script>alert('Allready exits');</script>";
	 	  }
	  else{
         $sql="insert into courses_pg(cat_name,cat_desc,path) values('".$name."', '".$con."','".$path."')";
	     $result = mysql_query($sql);
        echo "<script>alert('Inserted sucfully');</script>";
		header("location:viewcourse_pg.php");
	  }
}
?>
<html>
	<head>
		<title>Welcome to Chicago Telangana Association - Admin</title>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<link type="text/css" rel="stylesheet" href="css/admin.css"/>
		<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
		<script type="text/javascript" src="js/editor.js"></script>
		</head>
		 <script type="text/javascript" language="javascript" >
			function validate()
			{
			 if (document.getElementById('add').value=="")
					   {    
						  alert("Enter name");
						  document.getElementById('add').focus();
						  return false;
					   }
			 if (document.getElementById('files').value=="")
					   {    
						  alert("Please upload Image");
						  document.getElementById('files').focus();
						  return false;
					   }
			 if (document.getElementById('elm1').value=="")
					   {    
						  alert("Enter Content");
						  document.getElementById('elm1').focus();
						  return false;
					   }
			}
     </script>
	<body>
		<div id="main">
		<?php $page="courses";
		$locname='';
		include 'includes/header.php';//header
		include 'includes/sidebar.php';
		parse_str($_SERVER['QUERY_STRING']);
		error_reporting(E_ALL ^ E_NOTICE);
		?>
		<div id="center-column">
		<form method="POST" action=""  enctype="multipart/form-data" onsubmit="return validate();">
				<div class="table">
				<div id="heading">
						<span>Add Faclities::</span>
				</div>
				<br/><br/><br/><br/>
				<table>
				<tr><td>Title:</td><td><input type="text" name="name" id="add"></td></tr>
				<tr><td>Images:</td><td><input type="file" name="image" id="files"></td></tr>
					</table>
					<br/>
						<br/>	
					<div id="bg">
						<center>
							<textarea id="elm1" name="content" rows="40" cols="80" style="width: 80%">
								
							</textarea>
						<br />
									
							<input type="submit" name="submit"  value="Submit"/>
							<input type="reset" name="reset" value="Reset" />
						</center>
						</div><!--/bg-->
					</form>
				<script type="text/javascript">
				if (document.location.protocol == 'file:') {
				alert("The examples might not work properly on the local file system due to security settings in your browser. Please use a real webserver.");
				}
				</script>
				</div><!--/table-->
			</div><!--/center column-->
		   <?php include 'includes/footer.php';?>
     </div><!--/main-->
	</body>
</html>