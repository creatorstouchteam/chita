<?php
include "includes/dbconnect.php";
session_start();
$error='';
if($_SERVER["REQUEST_METHOD"] == "POST")
{
// username and password sent from Form
$myusername=addslashes($_POST['username']);
$mypassword=md5($_POST['password']);
$sql="SELECT id FROM admin_register WHERE username='$myusername' and password='$mypassword'";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);
//$active=$row['active'];
$count=mysql_num_rows($result);
// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1)
				{
				//session_register("myusername");
				$_SESSION['login_user']=$myusername;

				header("location: index.php");
				}
				else
				{
			   $error="Your Login Name or Password is invalid";
				}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
 <title>Welcome to Chicago Telangana Association - Admin</title>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link type="text/css" rel="stylesheet" href="css/login.css"/>
	</head>

<body>
<div id="content">
<div id="header">
       <img src="img/11.png">
</div>
<form action="" method="post">
	<table class="admin">
		<tr>
			<th colspan="2">Login To Admin</th>
		</tr>
		<tr><td colspan="2"><span class="error"><?php echo $error;?></span></td></tr>
		<tr>
			<td>Username </td>
			<td><input type="text" name="username"/></td>
		</tr>
		<tr>
			<td>Password </td>
			<td><input type="password" name="password"/></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value=" Submit " class="submit"/></td>
		</tr>
	</table>
	</div>
</form>

</body>
</html>