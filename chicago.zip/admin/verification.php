<?php
include 'includes/dbconnect.php';
session_start();
$user_check=$_SESSION['login_user'];

$ses_sql=mysql_query("select username from admin_register where username='$user_check'");

$row=mysql_fetch_array($ses_sql);

$login_session=$row['username'];

if(!isset($login_session))
{
	echo '<script type="text/javascript">' . "\n"; 
echo 'window.location="admin_login.php";'; 
echo '</script>'; 
}
?>