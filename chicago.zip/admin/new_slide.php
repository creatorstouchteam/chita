<?php  include 'verification.php';
function getExtension($str) {
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext; }
	error_reporting(E_ALL ^ E_NOTICE);
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		 $tmp=$_FILES["photo"]["tmp_name"];
		 $name = $_FILES["photo"]["name"];
		 list($width,$height)=getimagesize($tmp);
		// print_r(getimagesize($tmp));
		 $width=getimagesize($tmp);
		 $type = getExtension($name);
		 $path="img/".$name;
		 if(is_uploaded_file($_FILES["image"]["tmp_name"]))
			{
				move_uploaded_file($_FILES["image"]["tmp_name"], "../img/" . $_FILES["image"]["name"]);
				$path2="img/".$_FILES["image"]["name"];
			}
		 $title = $_POST['title'];
		 $content = $_POST['content'];
		if($name=='' )
		{
			$error1="Please choose Image.";
		}
		if($title == ''){
			$titleerror = "Please provide Title.";
		}
		if($content == ''){
			$contenterror = "Please provide content.";
		}
             
		 if($error1 == '' && $contenterror == ''){
					 if($type=='png' || $type=='JPG' || $type=='gif' || $type='jpeg' || $type='JPEG'){
							include 'includes/dbconnect.php';
 							$t = getExtension($name);
							list($width,$height)=getimagesize($tmp);
							 move_uploaded_file($tmp,"../img/" . $name);
								$query="select * from `slides`";
								$count=mysql_query($query);
								$row=mysql_num_rows($count);
								if($row <= 10){
								$sql="INSERT INTO slides( name,width,height,path,type,content,title) VALUES ('$path2','$width','$height','$path','$t','$content','$title')";									
										 mysql_query($sql);
										 header('location:slides.php?success=add');
								}else{
									$success="Slides are enoguh.";
								}
					 }
				
					 else{
					  $error="png,jpg,jpeg,gif images extensions only.";
					 }
			 }
		}
		?>
		
		
<!DOCTYPE html><head>
<title>Chicago Telangana Association - Admin</title>
<link type="text/css" rel="stylesheet" href="css/admin.css"/>
</head>
    
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    <link  href="css/admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="main">
	
	<?php 	$page="Slides";
		include 'includes/header.php';//header
		include 'includes/sidebar.php';//leftsidebar?>
	<div id="center-column">
		<div class="table">
		  <form name="form" method="post" action="" enctype="multipart/form-data" >
               <table class="listing" cellpadding="0" cellspacing="0">
         			<div id="heading">
						<span>New Slide upload here.</span>
					</div>
					<br/><br/><br/>
					<div class="error"><?php if(isset($error))echo $error;
					if(isset($error1)) echo $error1;?></div>
					<div class="error"><?php if(isset($contenterror))echo $contenterror;?></div>
					<div id="success"><?php if(isset($success)) echo $success; ?></div>

				<tr>
					<td>Images</td>
					<td style="text-align:left"><input type="file" name="photo" id="photo" value=""></br>
					<span style="color:#0070c0">Photo should be 980*340</span></td>
				</tr>
					<tr>
					<td>Small Images</td>
					<td style="text-align:left"><input type="file" name="image" id="photo" value=""></br>
					<span style="color:#0070c0">Photo should be 140*80,</span><span style="color:#0070c0">Photo name should be end with"_thumb" , Eg:1st_thumb.jpg</span></td>
				</tr>
				<tr>
					<td>Titlet</td>
					<td style="text-align:left">
		             <input type="text" name="title" id="title">
					</td>
				</tr>
				<tr>
					<td>Content</td>
					<td style="text-align:left">
					<textarea name="content" rows="10" cols="25"  maxlength="950">
		
					</textarea>	
					</td>
				</tr>
				<tr>
					<td></td>
					<td style="text-align:left"><input type="submit" name="submit" value="Submit" class="submit"></td>
				</tr>
				</table>
			</form>

</div><!--table-->
         </div><!--/center column-->
           <!--quick info-->
     </div><!--main-->
     <?php include 'includes/footer.php';?>
</body>
</html>