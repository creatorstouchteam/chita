<!DOCTYPE html>
 <?php include('verification.php');
?>
<html>
<head>
<title>Welcome to Chicago Telangana Association - Admin</title>
<link type="text/css" rel="stylesheet" href="css/admin.css"/>
</head>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    <link  href="css/admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="main">
	<?php $page="Images";
		include 'includes/header.php';//header
		include 'includes/sidebar.php';//leftsidebar?>
	<div id="center-column">
		
		 <div class="table">
                    <table class="listing" cellpadding="0" cellspacing="0">
                       <?php  
$data=$_SERVER["QUERY_STRING"];
parse_str($data);
$modify="modify";
$remove="remove";

if ($modify == isset($edit)) {
		function getExtension($str) {
				 $i = strrpos($str,".");
				 if (!$i) { return ""; }
				 $l = strlen($str) - $i;
				 $ext = substr($str,$i+1,$l);
				 return $ext;
		 }
$photo=$error=$error1=$titleerr=$contenterr=$success='';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$title=$_POST['title'];
			$content=$_POST['content'];
			$link=$_POST['link'];
			$name = $_FILES["photo"]["name"];
			$tmp=$_FILES["photo"]["tmp_name"];
			$type =getExtension($name);
			$path="img/".$name;
			$size=$_FILES["photo"]["size"];
	if($title==''){
		$titleerr="Please enter title";
	}
	if($content==''){
		$contenterr="Please enter content";
	}

	if($name==''){
					 $error1="Please choose Image.";
				 }//if name close
	 else{
			 if($type=='png' || $type=='jpg' || $type=='gif'|| $type='jpeg'){
					move_uploaded_file($tmp,"img/" . $name);
					include 'includes/dbconnect.php';
					 $sql="UPDATE `images` SET `name`='$name',`title`='$title',`path`='$path',`type`='$type',`content`='$content', `link`='$link' WHERE `image_id`='$id'";
					mysql_query($sql)or die('Could not connect: ' . mysql_error());
					header('location: images.php?success=s');
				}//if type of image close
			else{				
					$error="png,jpg,jpeg,gif images extensions only.";
				 }//else close
		}//else close
}//if post close
		?>


<div id="content">
<br/>
<?php
include 'includes/dbconnect.php';
$sql="SELECT * FROM `images` where `image_id`='$id'";
					 $images=mysql_query($sql) or die(mysql_error());
	while($image=mysql_fetch_array($images)){
?>
<form name="form" method="post" action="" enctype="multipart/form-data" >
<div id='success'>
	<?php echo $success;?>
</div>
<h1>Update Image</h1>
<table id="images" width="900px">
	<tr>
		<td align="right">Title :</td>
		<td><input type="text" size="" name="title" value="<?php echo htmlspecialchars($image['title']);?>">
		<span class="error"><?php echo $titleerr;?></span></td>
	</tr>
		
	<tr>
		<td align="right">Image:</td>
		<td id="error">
		<input type="file" name="photo" id="photo" value="">
		<span class="error"><?php echo $error;?></span>
		<span class="error"><?php echo $error1;?></span>
		</td>
	</tr>
	<tr>
		<td valign ="top"  align="right">Content For Image :</td>
		<td><textarea name='content' rows="16" cols="45" value="">
		<?php echo htmlspecialchars($image['content']);?></textarea>
		<span class="error"><?php echo $contenterr;?></span>
		</td>
	</tr>
	<tr>
		<td align="right">Link:</td>
		<td><input type="text" name="link" value="<?php echo htmlspecialchars($image['link']);?>"></td>
	</tr>

	<tr>
		<td></td>
		<td><input type="submit" name="submit" value="Submit" ></td>
	</tr>
</table>
</form>
<?php
}
}
?>
</div><!--content close-->

<?php if($remove=isset($delete)){
?>
	<div id="content">
		<div id="success">
			<?php
			 $sql="DELETE FROM `gallery` WHERE `image_id`='$id'";
			 $del=mysql_query($sql) or die(mysql_error());
			 if($del==1){
				 echo $suc;
				 header('location:images.php');
			 }
			 else{
				header('location:images.php');
			 }
			?>
		</div>
	</div>
<?php
}
?>
</table>

</div><!--table-->
         </div><!--/center column-->
           <!--quick info-->
     </div><!--spacing-->
     <?php include 'includes/footer.php';?>
</body>
</html>