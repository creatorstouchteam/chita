<?php require_once "verification.php"; ?>
<?php
if($_POST['hid_submit'] == "Submit"){
	$txtCurecases = $_POST['txtCurecases'];
	//$inc_case_id=$_POST['hid_id'];
	
	if($txtCurecases >0){
		for($i=1;$i<=$txtCurecases;$i++){
		
		    if($_FILES['txtImage'.$i]['name'] != ""){
			
				$result = $allClasses->forFileUpload_ren(DOC_ROOT_PATH."images/", 'txtImage'.$i);			
				if($result){
					$imgName = $result;
					
					$result = $allClasses->resizeImage(DOC_ROOT_PATH."images/".$imgName,202,202,DOC_ROOT_PATH."images/office_thumbs/".$imgName);
					
				}
				
				$querych = "insert into tbl_off_imgs(exp_id,img,title,dt_created) values('".$_POST['txtCategory']."','$imgName','".$_POST['txtTitle'.$i]."',current_date())";
			//echo $querych;
			$result = @mysql_query($querych);
			// $r=mysql_query("update tbl_off_imgs set exp_id='".$_POST['txtCategory']."' where inc_prod_id='".$inc_case_id."'");
			   // $r=mysql_query("update tbl_projects set exp_id='".$_POST['txtCategory']."' where inc_prod_id='".$inc_case_id."'");
			
			$error = mysql_error();
				if($error == ""){
				   $stat = "SUCCESS";
				}else{
				   $stat = "FAIL";
				}
				
	        }	
			
			
		}
	}
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?=$pgTitle?></title>
<link href="../css/admin.css" rel="stylesheet" type="text/css" />
<?php require_once "includes/header.php"; ?>
</head>

<body>
<table width="1003" border="0" align="center" cellpadding="0" cellspacing="0">
  
  <tr>
    <td height="150" align="left" valign="top" class="adminBGMiddle">
    
<table width="988" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td >&nbsp;</td>
  </tr>
  <tr>
   <td >
    <table width="100%" border="0" cellspacing="0" cellpadding="0">						
                            <tr>
                                <td width="15" align="left" valign="top">&nbsp;</td>
                                <td align="center" valign="middle" height="300">
 
<script language="javascript" type="text/javascript">
function go(id){
		window.location = 'addCorpImages.php?id='+trim(id);
	}
</script>
 
<script language="javascript" type="text/javascript">
function validate(){
  
 //var selcat=document.frmCase.txtCurecases.value; 
       
  	if(trim(document.frmCase.txtCategory.value)==''){
  		alert("Please select category.");
		document.frmCase.txtCategory.focus();
		return false;
	}
	if(trim(document.frmCase.txtCurecases.value)=='0'){
  		alert("No of images should not be Zero.");
		document.frmCase.txtCurecases.focus();
		return false;
	}
	if(document.frmCase.txtCurecases.value >0){
		for(i=1;i<=document.frmCase.txtCurecases.value;i++){
			img = document.getElementById('txtImage'+i).value;
		if(trim(img) == ""){
			alert("image should not be empty.");
			document.getElementById('txtImage'+i).focus();
			return false;
		}
		
		var lpos = img.lastIndexOf('.');
		ext = img.substr(lpos+1);
		ext = ext.toLowerCase();
		if(ext != "jpeg" & ext !='gif' & ext !='png' & ext !='jpg'){
			alert("Please select a jpeg or jpg or gif or png image.");
			document.getElementById('txtImage'+i).focus();
			return false;
		}
			
		}
		}

return true;
}

var vldnum=/^[0-9]+$/;
var i =0;	

function displayChildInfo(caseimages){

	
	var txtImageDetails = "";
	match=vldnum.test(caseimages);
	if(!match){	  
		alert("Enter numbers only.");
		document.frmCase.txtCurecases.focus();
		return false;
	}else{
		if(caseimages >0){
			for(i=1;i<=caseimages;i++){
				txtImageDetails += '<table width="60%" border="0" cellspacing="4" cellpadding="0"><tr><td align="left" valign="middle"class="bold_txt">Image'+i+'</td><td align="left" valign="middle"><input name="txtImage'+i+'" type="file" class="forTextfield" id="txtImage'+i+'" maxlength="255" /></td></tr><tr><td align="left" valign="middle"class="bold_txt">Title'+i+'</td><td align="left" valign="middle"><input name="txtTitle'+i+'" type="text" class="forTextfield" id="txtTitle'+i+'" maxlength="255" /></td></tr><tr><td colspan="2" class="content_txt" align="center" valign="middle">........................................</td></tr></table>';	
				//document.getElementById('divImageInfo').innerHTML += txtImageDetails;
			}
		}else{
			document.getElementById('divImageInfo').innerHTML = '';
		}
	}
	if(txtImageDetails != ""){
		document.getElementById('divImageInfo').innerHTML = txtImageDetails;
	}
	}		
</script>                             
	<form name="frmCase" enctype="multipart/form-data" action="" method="post" onsubmit="return validate();">
		<table width="80%"  border="0" cellpadding="0" cellspacing="1" class="border"  >
		     
             <tr>
              <td colspan="3" align="left" valign="middle">
              <?php
if($stat != ""){

?>    
 <table width="80%" border="0" align="center" cellpadding="0" bgcolor="#E9E9E9" cellspacing="6" class="border" >
<?php
	if($stat == "SUCCESS"){ 
?>	
	<tr>
    	<td width="22%" align="center" valign="middle" >&nbsp;</td>
	</tr>
    <tr>
    	<td width="22%" align="center" valign="middle" class="successMsg" style="color:#009933">Images has been updated successfully.</td>
	</tr>
<?php
	}
	if($stat == "FAIL"){    
?>	
	<tr>
    	<td width="22%" align="center" valign="middle" >&nbsp;</td>
	</tr>
    <tr>
	  <td align="center" valign="middle" class="redtext2">Error: Unable to Insert Images. Please try again.</td>
	</tr>
<?php
	}
?>	  
	  
	
</table>    
<?php
}
?> 

              </td>
              
             </tr>
             <tr> 
            	<td width="44%" height="25" align="left" valign="middle" class="subheading" style="padding-left:20px">Add   Images :</td>

				<td width="2%" align="left" valign="middle" class="bold_txt"></td>
                <td width="54%" align="left" valign="middle">&nbsp;</td>
            </tr>
            <tr>
              <td colspan="2" align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">&nbsp;</td>
            </tr>
 <!--------------------------------------------------------------------------------------------> 

 			  <tr>
                <td align="left" valign="middle" class="bold_txt" height="30" style="padding-left:150px">Category </td>
                <td width="2%" align="left" valign="middle" class="bold_txt"></td>
                <td align="left" valign="middle"><select name="txtCategory" class="forTextfield" id="txtCategory" onchange="return go(this.value);" >
                   <option value="" selected="selected">--Category--</option>
					<?php
					$rs = mysql_query("select * from tbl_corporate_cat ");
					$len=mysql_num_rows($rs);
					//echo $len;
					while($row=mysql_fetch_array($rs))
					{
					   $selected="";
						if($_REQUEST['id']==$row['inc_cat_id']){ 
						   $sel="selected='selected'"; 
						}else{ 
						   $sel="";
						}						
					
		               echo '<option '.$sel.' value="'.$row['inc_cat_id'].'" >'.$row['cat_name'].'</option>';
		            }
			        ?>                           	    
                                    </select>
                                    
                                    </td>
             </tr>	
             <tr>
                <td align="left" valign="middle" class="bold_txt" height="30" style="padding-left:150px">No of Images </td>
                <td width="2%" align="left" valign="middle" class="bold_txt"></td>
                <td align="left" valign="middle"><input name="txtCurecases" type="text" class="forTextfield"  id="txtCurecases" size="3" maxlength="2" value="0" onkeyup="displayChildInfo(this.value)" /></td>
             </tr>
              <tr>
                <td align="left" valign="middle">&nbsp;</td>
                <td width="2%" align="left" valign="middle" class="bold_txt"></td>
                <td align="left" valign="middle">
                
            <div id="divImageInfo"></div>    </td>
              </tr>
 <!-------------------------------------------------------------------------------------------->
            <tr>
              <td colspan="2" align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">&nbsp;</td>
            </tr>
            <tr> 
	            <td colspan="2" align="left" valign="middle">&nbsp;</td>
				
    	        <td align="left" valign="middle"><input name="hid_submit" type="submit" class="forButton" id="hid_submit" value="Submit" /></td>
            </tr>
            <tr>
              <td colspan="2" align="left" valign="middle">&nbsp;</td>
              <td align="left" valign="middle">&nbsp;</td>
             </tr>
             <tr>
              <td colspan="2" align="left" valign="middle" style="padding-left:25px" class="subheading"> Images</td>
              <td align="left" valign="middle">&nbsp;</td>
             </tr>
             <tr>
              <td colspan="3" align="center" valign="middle" style="padding:20px">
    <?php
            if($_REQUEST['act'] == "del" && is_numeric($_REQUEST['prodimg'])){
	        //$upload_type = "image";			 
				
			  $queryI = "select * from tbl_off_imgs where inc_img_id=".$_REQUEST['prodimg'];
			  $resultI = mysql_query($queryI);
				if(mysql_num_rows($resultI)>0){
					$rowI = mysql_fetch_array($resultI);		
					
					$query2 = "delete from tbl_off_imgs where inc_img_id=".$_REQUEST['prodimg'];
					$result2 = mysql_query($query2);
					$error = mysql_error();
				
					if($error == ""){
						unlink(ROOT_IMG_PATH.$rowI['img']);
						unlink(ROOT_IMG_PATH."office_thumbs/".$rowI['img']);
						$msg = '<div align="center" class="redtext2">Record has been removed successfully.</div>';
					}else{
						$msg = '<div align="center" class="redtext2">Error: Unable to remove record. Please try again.</div>';
					}
				}
            }
            ?>
            <?php
if($msg!=''){

?>    
 <table width="80%" border="0" align="center" cellpadding="0" bgcolor="#E9E9E9" cellspacing="6" class="border" >
	
	
    <tr>
    	<td width="22%" align="center" valign="middle" class="greentext" style="color:#009933"><?=$msg?></td>
	</tr>
    </table>
<?php
	}
	?>
     <table width="80%" border="0" class="border" cellspacing="0" cellpadding="0" style="padding:8px" bgcolor="#F3F3F3">
                    <tr>
					  <?php
					  if($_REQUEST['id']!=""){
                        $query="select * from tbl_off_imgs where exp_id='".$_REQUEST['id']."' order by inc_img_id desc ";
                        $result=mysql_query($query);
                        $i=1;
                        while($row=mysql_fetch_array($result)){
                      ?>
                      
                        <td width="25%" align="center" style="padding-left:5px">
                        <img src="../images/office_thumbs/<?=$row['img']?> " class="border2" width="100" height="100" >
                        <a href="javascript:void(0)" onClick="if(confirm('Do you want to remove?')){window.location.href='<?=$_SERVER['PHP_SELF']."?act=del&prodimg=".$row['inc_img_id']."&id=".$row['exp_id']."&pageId=".$pageId?>';return false;}"><img src="../images/x.GIF" border="0" alt="delete" /></a>
                        </td>
                        <td>&nbsp;</td>
                       <?php
                       if($i%4==0){
                           echo '</tr><td colspan="2" height="10"></td><tr>';
                       }
                       ?>
                       <?php $i++; }
					  }
					   ?> 
                     </tr>
                   </table>
      </td>
              
             </tr>
        </table>
        </form>
        
        </td>
        <td width="12" align="left" valign="top">&nbsp;</td>
                        </tr>
                    </table>
             </td>       
  </tr>
  <tr>
    <td >&nbsp;</td>
  </tr>
  <tr>
    <td >&nbsp;</td>
</tr>
  <tr>
    <td align="left" valign="middle"><?php require_once "../includes/ui_admin_footer.php"; ?></td>
  </tr>
</table>    
    </td>
  </tr>
  <tr>
    <td height="9" align="left" valign="top" class="adminBGBottom"></td>
  </tr>
</table>
</body>
</html>