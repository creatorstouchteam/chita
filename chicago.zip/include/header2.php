<!DOCTYPE html>
<html>
<head>
<title>Photos</title>


<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700,800' rel='stylesheet' type='text/css' />
<link href="css/style.css" rel="stylesheet" media="screen" type="text/css" />
<link href="css/ipad.css" rel="stylesheet" media="screen" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" media="screen" type="text/css" />
<link href="css/mobile.css" rel="stylesheet" media="screen" type="text/css" />



<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/jquery.cookie.js"></script>
<script type="text/javascript" src="js/jquery.fancydropdown.js"></script>

<!--Rating-->
<script type="text/javascript" src="js/jquery.rating.pack.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$('input.star').rating();
});
</script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/pop_bubble.js"></script>

<!-- Scrolling Script -->
<link href="css/jquery.mCustomScrollbar.css" rel="stylesheet" media="screen" type="text/css" />
<script type="text/javascript" src="js/jquery.mousewheel.min.js"></script>
<!-- custom scrollbars plugin -->
<script type="text/javascript" src="js/jquery.mCustomScrollbar.js"></script>

<!-- Quicksand Script -->
<script type="text/javascript" src="js/jquery.quicksand.js"></script>

<!-- Fancy box Script -->
<!-- Add fancyBox main JS and CSS files -->
<script type="text/javascript" src="js/fancybox/jquery.fancybox.pack.js?v=2.1.0"></script>
<link rel="stylesheet" type="text/css" href="js/fancybox/jquery.fancybox.css?v=2.1.0" media="screen" />
<!-- Add Media helper -->
<script type="text/javascript" src="js/fancybox/helpers/jquery.fancybox-media.js?v=1.0.3"></script>

</head>

<body>


<div id="main-container"> 
	<!-- Header -->
	<div style="width:940px;
	background:#fff url(images/headerBG.png) top center;
	padding:10px;
	float:left;">
        <div class="logo"><a href=""><img src="images/logo.png" alt="" /></a></div>
        <div class="righthead">
            <div class="top-menu inline">
                <ul>
                   
                    <li class="signin"> <a href="#" id="signin">Quick Enquiry</a> 
                        
                        <!-- SignIn Dialog -->
                        <div id="signinbox" class="gray_gradient"> <img src="images/sign_in_arrow.png" alt="" class="boxArrow" />

                            <div id="signin_menu">

                                <div class="box_heading"> Enquiry <a href="#" class="close"><img id="fadeouta" src="images/close.png" alt="" width="16" height="16" /></a> </div>

                   <div id="contact_menu">

                                <?php
	
if(isset($_POST['s1']))
{
	session_start();
	$error=' ';
	
		
		$to = 'info@vijayahospitals.com';
		$headers = 	'From: '.$_POST['e1'].''. "\r\n" .
				'Reply-To: '.$_POST['e1'].'' . "\r\n" .
				'X-Mailer: PHP/' . phpversion();
		$subject = "Mail from Vijaya hospital From Quick Enquiry";
		
		
		$message=$message."Fullname: ".$_POST['n1'] . "\r\n";
		$message=$message."Mobile: ".$_POST['p1']. "\r\n" ;
		$message=$message."Email Id: ".$_POST['e1']. "\r\n";
		
		$message=$message."message: ".$_POST['m1']. "\r\n";
		
		
		
		
		if(mail($to, $subject, $message, $headers))
		{//we show the good guy only in one case and the bad one for the rest.
			$error='Your Message Sent. Thank you '.$_POST['n1'].'.';
		}
		else {
			$error="Message not sent.";
		}
	
}



?> <form method="post" action="">

                                    <input type="text"  name="n1" placeholder="Name"  required="required"  />

                                    <input type="text" name="e1" placeholder="Email" required="required" />

                                    <input type="text"  name="p1"  placeholder="Phone"  required="required" />

                                    <p>

                                        <textarea name="m1" cols="5" rows="5" placeholder="Message" required="required"></textarea>

                                    </p>

                                    <input class="contact_submit" value="Submit" tabindex="6" type="submit" name="s1"/>

                                    <input class="contact_submit" value="Reset" tabindex="6" type="reset" />

                                    <div class="clear"></div>
<span style="color:#f00;"><?php echo $error; ?></span>
                                </form>
                               

                            </div>

                            </div>

                        </div>
                    </li>
                    <li class="contact"> <a href="#" id="contact">contact</a> 
                        <!-- Contact Dialog -->
                        <div id="contactbox" class="gray_gradient"> <img src="images/sign_in_arrow.png" alt="" class="boxArrow" />

                            <div class="box_heading"> Contact us <a href="#" class="close"><img id="fadeout" src="images/close.png" alt="" width="16" height="16" /></a> </div>

                            <h6>Vijaya Super Speciality Hospitals</h6>World class health care with in reach...

                            

                            <div class="coll_left left">Office 24/7 Avalible<br />Suryarao Pet<br />

                                vijayawada<br />

                                Andhra Pradesh</div>

                            <div class="coll_right right">Pin: 500002<br />

                                Phone: 0866.2435300<br />

                                Email: info@vijayahospitals.com</div>

                            <div class="clear"></div>

                            

                            <!-- Google Map -->

                            <div class="google_map margin_bottom margin_top">

                                <iframe width="301" height="135" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=vijaya+super+speciality+hospital,+vijayawada,+andhra+pradesh&amp;aq=&amp;sll=12.963092,77.627352&amp;sspn=0.137677,0.154324&amp;ie=UTF8&amp;hq=vijaya+super+speciality+hospital,&amp;hnear=Vijayawada,+Krishna,+Andhra+Pradesh&amp;t=h&amp;cid=7379894725948137960&amp;ll=16.513947,80.638103&amp;spn=0.011109,0.025749&amp;z=14&amp;output=embed"></iframe>

                            </div>

                            

                            

                            

                        </div>
                    </li>
                </ul>
            </div>
            
            <!-- Helpline -->
            <div class="contactinfo"> <span class="black_text">24/7 HELPLINE</span> </div>
             <div class="contactinfo"> <span class="phonenumber" style="font-size:24px;">0866 2435300</span> </div>
            <!-- Live Chat -->
            
        </div>

    </div>

	<!-- Mega Menu starts -->
    <div class="menu container">
        <ul id="menu">
        <ul id="menu">
            <li class="column"><a href="index.php"><strong>Home</strong></a>
                
          </li>
            <li><a href="#"><strong>About us</strong></a>
                <div class="dropdown_columns">
                    <div class="col_2">
                        <ul>
						<?php include'include/dbconnect.php';
						$sql="select * from about";
						$query=mysql_query($sql);
						while($row=mysql_fetch_array($query)){?>
                             <li><a href="aboutus.php?id=<?php echo $row['inc_cat_id'];?>"><?php echo $row['cat_name'];?></a></li>
                        <?php }?>
						</ul>
                    </div>
                </div>
            </li>
            <li class="column"><a href="#"><strong>Departments</strong></a>
                <div class="dropdown_columns">
                    <div class="col_2">
                        <ul>
						<?php include'include/dbconnect.php';
						$sql="select * from tbl_notifications_cat";
						$query=mysql_query($sql);
						while($row=mysql_fetch_array($query)){?>
                             <li><a href="department.php?id=<?php echo $row['inc_cat_id'];?>"><?php echo $row['cat_name'];?></a></li>
                        <?php }?>
						</ul>
                        </div>
                </div>
            </li>
            <li class="column"><a href="#"><strong>Services</strong></a>
                <div class="dropdown_columns">
                    <div class="col_2">
                        <ul>
						<?php include'include/dbconnect.php';
						$sql="select * from service";
						$query=mysql_query($sql);
						while($row=mysql_fetch_array($query)){?>
                             <li><a href="services.php?id=<?php echo $row['inc_cat_id'];?>"><?php echo $row['cat_name'];?></a></li>
                        <?php }?>
						</ul>                    </div>
                </div>
            </li>
            <li class="column"><a href="#"><strong>Facilities</strong></a>
                <div class="dropdown_columns">
                    <div class="col_2">
                    <ul>
						<?php include'include/dbconnect.php';
						$sql="select * from facilities";
						$query=mysql_query($sql);
						while($row=mysql_fetch_array($query)){?>
                             <li><a href="facilites.php?id=<?php echo $row['inc_cat_id'];?>"><?php echo $row['cat_name'];?></a></li>
                        <?php }?>
					</ul>
                    </div>
                </div>
            </li>
            <li class="column"> <a href="#"><strong>Doctors</strong></a><div class="dropdown_columns">
                    <div class="col_2">
                        <ul>
                           	<?php include'include/dbconnect.php';
						$sql="select * from doctors";
						$query=mysql_query($sql);
						while($row=mysql_fetch_array($query)){?>
                             <li><a href="docotrs.php?id=<?php echo $row['inc_cat_id'];?>"><?php echo $row['cat_name'];?></a></li>
                        <?php }?>
                        </ul>
                    </div>
                </div> </li> <li > <a href="infra.php"><strong>Infrastructure</strong></a>
                
            </li>
            <li class="column"> <a href=""><strong>Gallery</strong></a><div class="dropdown_columns">
                    <div class="col_2">
                        <ul>
                            <li><a href="media.php">Media</a></li>
                            <li><a href="gallery.php">Photos</a></li>
                            <li><a href="videos.php">Videos</a></li>
                            
                        </ul>
                    </div>
                </div> 
                
            </li>
             <li > <a href="enquiry.php"><strong>Enquiry</strong></a>
                
            </li>
            <li> <a href="contact.php"><strong>Contact us</strong></a> </li>
        </ul></div>