<!-- Top Bar Starts -->
        <div class="topBar">
        	<div class="row">
            
            	<div class="large-4 medium-4 small-12 columns left-side">
                	<p><strong> Toll Free </strong> <i class="fa fa-phone"></i> - 1800-270-1058 </p>
                </div><!-- Left Column Ends /-->
            
            	<div class="large-8 medium-8 small-12 columns">
                    <ul class="menu text-right">
                        <li> <a href=""> <i class="fa fa-angle-double-right"></i> Sponsors  </a> </li>| 
						<li> <a href="donate.php"> <i class="fa fa-angle-double-right"></i> Donate now </a>  </li>| 
                        <li> <a href="membership.php"> <i class="fa fa-angle-double-right"></i> Join now </a>  </li>|
						<li> <a href=""> <i class="fa fa-lock"></i> Register with Us </a></li>| 
                        <li> <a href=""> <i class="fa fa-angle-feed"></i> Feedback </a>  </li> 
                        <!--<li class="first-social social"><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li class="social"><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li class="social"><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li class="social"><a href="#"><i class="fa fa-google"></i></a></li>-->
                    </ul>
                </div><!-- Right column Ends /-->
            
            </div><!-- Row ends /-->
        </div>
        <!-- Top bar Ends /-->
        
        <!-- Header Starts -->
        <div class="header">
        	<div class="row">
            	
                <div class="medium-4 small-12 columns">
                	<div class="logo">
                    	<a href="index.php">
                        	<img src="images/logo.png" alt="Chicago Telangana Association" />
                        </a>    
                    </div><!-- logo /-->
                </div><!-- left Ends /-->
                
                <div class="medium-8 small-12 columns nav-wrap">
                	<!-- navigation Code STarts here.. -->
                    <div class="top-bar">
                        <div class="top-bar-title">
                            <span data-responsive-toggle="responsive-menu" data-hide-for="medium">
                                <a data-toggle><span class="menu-icon dark float-left"></span></a>
                            </span>
                        </div>
                      
                        <nav id="responsive-menu">
                            <ul class="menu vertical medium-horizontal float-right" data-responsive-menu="accordion medium-dropdown">
                                <li><a href="index.php">Home</a></li>
								
                                <li class="single-sub parent-nav"><a href=""> About Us</a>
                                    <ul class="child-nav menu vertical">
                            <?php include'dbconnect.php';
							$sql="select * from about ORDER BY `about`.`inc_cat_id` ASC ";
							$query=mysql_query($sql);
							while($row=mysql_fetch_array($query)){?>
                            <li><a href="about-us.php?id=<?php echo $row['inc_cat_id'];?>"> <?php echo $row['cat_name'];?> </a></li><?php }?>                                 
                                    </ul>
                                </li>
                                                                
                                
                                <li class="single-sub parent-nav"><a href=""> Charity/ Projects </a>
                                    <ul class="child-nav menu vertical"> 
                             <?php include'dbconnect.php';
							$sql="select * from departments ORDER BY `departments`.`inc_cat_id` ASC ";
							$query=mysql_query($sql);
							while($row=mysql_fetch_array($query)){?>
                            <li><a href="project-page.php?id=<?php echo $row['inc_cat_id'];?>">
							<?php echo $row['cat_name'];?> </a></li><?php }?>                                  
                                    </ul>
                                </li>
								<li><a href=""> Membership </a></li>
								 <li class="single-sub parent-nav"><a href=""> GALLERY </a>
                                    <ul class="child-nav menu vertical"> 
                                    	<li><a href="gallery.php">  Photos  </a></li>  
                                    	<li><a href="videos.php">  Videos </a></li> 
                                                                    
                                    </ul>
                                </li>
								<!--<li><a href="">Feedback</a></li>-->
								<li><a href="contact.php">Contact Us</a></li>
                            </ul>
                        </nav>
                    </div><!-- top-bar Ends -->
                    <!-- Navigation Code Ends here -->
                    <!--<div class="search-wrap float-right">
	                    <a href="#" class="search-icon-toggle" data-toggle="search-dropdown"><i class="fa fa-search"></i></a>
    				</div> --><!-- search wrap ends -->
                    <div class="dropdown-pane" id="search-dropdown" data-dropdown data-auto-focus="true">
                      <input type="text" placeholder="Enter keyword and press enter .... " />
                    </div>
                </div><!-- right Ends /-->
                
            </div><!-- Row Ends /-->
        </div>
        <!-- Header Ends /-->