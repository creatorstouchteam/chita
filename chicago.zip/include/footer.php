<div class="footer">
            <div class="footerTop">
            
                <div class="row">
                
                    <div class="large-3 medium-6 small-12 columns footer-widget">
                        <h2>About Us</h2>
                        <div class="tx-div"></div>
                        <p>
						<img src="images/logo.png">

						
						<p> Chicago Telangana Association (CHITA) is a not-for-profit organisation of Telangana people living in and around Chicago land area.  </p>
                    </div><!-- Widget 1 ends /-->
                    
                    <div class="large-3 medium-6 small-12 columns footer-widget quick-links">
                        <h2>Quick Links</h2>
                        <div class="tx-div"></div>
                        <ul  class="menu vertical">
						<li><a href="index.php">Home</a></li>
						<li><a href="about.php">About Us</a></li>
                        <li><a href="">Membership</a></li>
                        <li><a href="project-page.php">Charity/ Projects</a></li>
						<li><a href="latest-news-events.php">News & Events</a></li>
                        <li><a href="">Latest News</a></li>
						<!--<li><a href="">Our Success</a></li>/-->
                        </ul>
                        <ul  class="menu vertical">
                            
   						<li><a href="">News & Events</a></li>
    					<li><a href="">Sponsors</a></li>
    					<li><a href="">Donate now</a></li>
    					<li><a href="">Registration</a></li>
     					<li><a href="gallery.php">Gallery</a></li>
						<li><a href="contact.php">Contact Us</a></li>
					
                        </ul>
                    </div><!-- Widget 2 Ends /-->
                    
                    
                    
                    <div class="large-3 medium-6 small-12 columns footer-widget">
                    <div class="textwidget">
                        <ul class="address">
                            <li>
                                <i class="fa fa-home"></i>
                                <h4>Address:</h4>
                                <p> 228 Cortez Ct, Naperville IL 60563 </p>
                            </li>
                            <li>
                                <i class="fa fa-mobile"></i>
                                <h4>Phone:</h4>
                                <p> 001-630-730-2007 </p>
                            </li>
                            <li>
                                <i class="fa fa-envelope"></i>
                                <h4>Email:</h4>
                                <p> chita.org@gmail.com </p>
                            </li>
                        </ul>
                        <hr>
                        <div class="socialicons">
                            Social: 
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-google"></i></a>
                        </div><!-- Social Icons /-->
                    </div><!-- text widget /-->
                </div><!-- widget 3 /-->  
                
                <div class="large-3 medium-6 small-12 columns footer-widget">
                        <h2> Location Map </h2>
                        <div class="tx-div"></div>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m10!1m3!1d380215.47809478664!2d-87.65617!3d41.883535!2m1!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x64d3fefce3a4a51!2sCloud+Gate!5e0!3m2!1sen!2sus!4v1499520254736" width="100%" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
                    </div><!-- Widget 4 Ends /-->              
                    <div class="clearfix"></div>
                
                </div><!-- Row Ends /-->
            
            </div><!-- footerTop Ends here.. -->
        
            <div class="footerbottom">
            
                <div class="row">
                
                    <div class="medium-6 small-12 columns">
                        <div class="copyrightinfo">2017 &copy; <a href="#"> Chicago Telangana Association</a> All Rights Reserved.</div>
                    </div><!-- left side /-->
                    
                
                </div><!-- Row /-->
            
            </div><!-- footer Bottom /-->
        </div>