<!doctype html>
<html lang="en">
<head>
    <!-- important for compatibility charset -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    
    <title>Videos | Chicago Telangana Association</title>
    
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta name="description" content="">
    
    <!-- important for responsiveness remove to make your site non responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- FavIcon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
    
    <!-- Animation CSS -->
    <link rel="stylesheet" type="text/css" href="css/animate.css" media="all" />
    
    <!-- Foundation CSS File -->
    <link rel="stylesheet" type="text/css" href="css/foundation.min.css" media="all" />
    
    <!-- Font Awesome CSS File -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" media="all" />
    
    <!-- Owl Carousel CSS File -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" media="all" />
    
    <!-- Lightbox IMage Gallery Plugin CSS -->
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" media="all" />
    
    <!-- Theme Styles CSS File -->
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    
    <!-- Google Fonts For Stylesheet --> 
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CMontserrat:400,700" rel="stylesheet" type="text/css" />
    
    
</head>

<body>
    <!-- Page Preloader -->
    <div id="loading">
        <div id="loading-center">
            <div id="loading-center-absolute">
            	<div id="object"></div>
            </div>
        </div>
    </div>
    <!-- Page Preloader Ends /-->

	<!-- Main Container -->
    <div class="main-container">
    	
        <?php include'include/header.php';?>
        
        <!-- Title Section -->
        <div class="title-section module">
            <div class="row">
        
                <div class="small-12 columns">
                    <h1>Our Videos</h1>
                </div><!-- Top Row /-->
        
                <div class="small-12 columns">
                    <ul class="breadcrumbs">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Gallery</a></li>
                        <li><span class="show-for-sr">Current: </span> Videos</li>
                    </ul><!-- Breadcrumbs /-->
                </div><!-- Bottom Row /-->
                
            </div><!-- Row /-->
        </div>
        <!-- Title Section Ends /-->
        
        
        <div class="content-section module">
        	
            <!-- Seminar/Events -->
            <div class="space-section module">
            <div class="section-title-wrapper">
                    <div class="section-title">
                        <h2>Videos</h2>
                    </div>
                </div>
                <div class="row">
                    
                    <div class="events-wrapper">
                        
    <?php
		include'dbconnect.php';
 $query = "select  * from tbl_videos  order by video_inc_id desc";
	$result = @mysql_query($query);
	while($row = @mysql_fetch_array($result)){
if($row['vedio_url'] != ""){
	$qs = substr($row['vedio_url'], strrpos($row['vedio_url'], "?")+1, strlen($row['vedio_url']));				
	$params = explode('&',$qs);					
	$vidString = "";
	foreach($params as $param){
		$vidParams = explode('=',$param);	
		if($vidParams[0] == 'v'){
			$vidString = $vidParams[1];
		}
	}                    
}
if($vidString != ""){
?>
    <div class="medium-4 small-6 columns">
                    	<div class="event">
                    		<div class="">
                            	<iframe width="100%" height="300" src="https://www.youtube.com/embed/<?php echo $vidString?>" frameborder="0" allowfullscreen></iframe>
                                <h4 class="text-center"><?php echo $row['video_title'];?></h4>
                            </div><!-- Event DAta /-->
                            <!-- Event thumb /-->    	
                        	<div class="clearfix"></div>
                        </div><!-- Event div ends /-->
     </div><?php }}?>
                    
                    
                    </div><!-- Events Wrapper Ends /-->
                    
                </div><!-- Row Ends /-->
            </div>
            <!-- Seminar Events Ends /-->
            
            
        </div>
        
        
        <!-- Call to Action box -->
        <div class="call-to-action">
           <div class="row">
                <div class="medium-10 small-12 columns">
                    <h2><i class="fa fa-phone" aria-hidden="true"></i> 	If you Have Any Questions Call Us On <span>(010)123-456-7890</span></h2>
                </div>
                <div class="medium-2 small-12 columns">
                    <a href="#" class="button secondary">Appointment</a>
                </div>
           </div><!-- row /-->
         </div>
        <!-- Call to Action End /-->
        
        <!-- Footer -->
        <?php include'include/footer.php';?>
        <!-- Footer Ends here /-->
        
    </div>
    <!-- Main Container /-->
	
    <a href="#top" id="top" class="animated fadeInUp start-anim"><i class="fa fa-angle-up"></i></a>

    <!-- Including Jquery so All js Can run -->
    <script type="text/javascript" src="js/jquery.js"></script>
    
    <!-- Including Foundation JS so Foundation function can work. -->
    <script type="text/javascript" src="js/foundation.min.js"></script>
    
    <!-- Including Owl Carousel File -->
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    
    <!-- Webful JS -->
    <script src="js/webful.js"></script>
    
    <!-- Including LightBox Plugin Delete if not using -->
    <script src="js/lightbox.min.js"></script>
</body>
</html>