<!doctype html>
<html lang="en">
<head>
    <!-- important for compatibility charset -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    
    <title>Membership | Chicago Telangana Association</title>
    
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta name="description" content="">
    
    <!-- important for responsiveness remove to make your site non responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- FavIcon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
    
    <!-- Animation CSS -->
    <link rel="stylesheet" type="text/css" href="css/animate.css" media="all" />
    
    <!-- Foundation CSS File -->
    <link rel="stylesheet" type="text/css" href="css/foundation.min.css" media="all" />
    
    <!-- Font Awesome CSS File -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" media="all" />
    
    <!-- Owl Carousel CSS File -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" media="all" />
    
    <!-- Theme Styles CSS File -->
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    
    <!-- Google Fonts For Stylesheet --> 
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CMontserrat:400,700" rel="stylesheet" type="text/css" />
    
    
</head>

<body>
    <!-- Page Preloader -->
    <div id="loading">
        <div id="loading-center">
            <div id="loading-center-absolute">
            	<div id="object"></div>
            </div>
        </div>
    </div>
    <!-- Page Preloader Ends /-->

	<!-- Main Container -->
    <div class="main-container">
    	
        <?php include'include/header.php';?>
        
        <!-- Title Section -->
        <div class="title-section module">
            <div class="row">
        
                <div class="small-12 columns">
                    <h1>Membership </h1>
                </div><!-- Top Row /-->
        
                <div class="small-12 columns">
                    <ul class="breadcrumbs">
                        <li><a href="#">Home</a></li>
                        <li><span class="show-for-sr">Current: </span> Membership </li>
                    </ul><!-- Breadcrumbs /-->
                </div><!-- Bottom Row /-->
                
            </div><!-- Row /-->
        </div>
        <!-- Title Section Ends /-->
        
        <!-- Content Area Starts -->
       	<div class="content-area module faq">
	    	<div class="row">
            
        		<div class="medium-9 small-12 columns">
                	<h2>Please Fill the Form below.</h2>
                    <p>Once we receive your information our representative will get back to you within 24 hours.</p>
					<div class="contact-form">
    
                    <div class="row">
                        <div class="medium-6 small-12 columns">
                            <label>
                                <input type="text" value="" placeholder="Your name here..." />
                            </label>    
                        </div>
                        <div class="medium-6 small-12 columns">
                            <label>
                                <input type="text" value="" placeholder="Your last name here..." />
                            </label>
                        </div>
                    </div><!-- Row Ends /-->
                        
                    <div class="row">
                        <div class="medium-6 small-12 columns">
                            <label>
                                <input type="text" value="" placeholder="Enter your Phone ..." />
                            </label>    
                        </div>
                        <div class="medium-6 small-12 columns">
                            <label>
                                <input type="text" value="" placeholder="Enter Email ..." />
                            </label>
                        </div>
                    </div><!-- Row Ends /-->
                        
                    <div class="row">
                        <div class="medium-12 small-12 columns">
                            <label>
                                <select>
                                    <option value="1">Reason for Joining</option>
                                    <option value="2">Reasone 1</option>
                                    <option value="3">Reasone 2</option>
                                </select>
                            </label>    
                        </div>
                    </div>
                    <div class="row">    
                        <div class="medium-12 small-12 columns">
                            <label>
                                <select>
                                    <option value="Select County">Select County</option>
                                    <option value="74">Aberdeenshire</option>
                                    <option value="51">Anglesey</option>
                                    <option value="75">Angus</option>
                                    <option value="76">Argyll</option>
                                    <option value="1">Avon</option>
                                    <option value="77">Ayrshire</option>
                                    <option value="78">Banffshire</option>
                                    <option value="3">Bedfordshire</option>
                                    <option value="90">Berkshire</option>
                                    <option value="79">Berwickshire</option>
                                    <option value="52">Breconshire</option>
                                    <option value="4">Buckinghamshire</option>
                                    <option value="80">Bute</option>
                                    <option value="53">Caernarvonshire</option>
                                    <option value="81">Caithness</option>
                                    <option value="5">Cambridgeshire</option>
                                    <option value="54">Cardiganshire</option>
                                    <option value="55">Carmarthenshire</option>
                                    <option value="6">Cheshire</option>
                                    <option value="82">Clackmannanshire</option>
                                    <option value="7">Cornwall and Isles of Scilly</option>
                                    <option value="8">Cumbria</option>
                                    <option value="56">Denbighshire</option>
                                    <option value="9">Derbyshire</option>
                                    <option value="10">Devon</option>
                                    <option value="11">Dorset</option>
                                    <option value="84">Dumbartonshire</option>
                                    <option value="83">Dumfriesshire</option>
                                    <option value="12">Durham</option>
                                    <option value="85">East Lothian</option>
                                    <option value="13">East Sussex</option>
                                    <option value="14">Essex</option>
                                    <option value="86">Fife</option>
                                    <option value="44">Flintshire</option>
                                    <option value="45">Glamorgan</option>
                                    <option value="15">Gloucestershire</option>
                                    <option value="16">Greater London</option>
                                    <option value="17">Greater Manchester</option>
                                    <option value="18">Hampshire</option>
                                    <option value="19">Hertfordshire</option>
                                    <option value="87">India</option>
                                    <option value="87">Inverness</option>
                                    <option value="20">Kent</option>
                                    <option value="88">Kincardineshire</option>
                                    <option value="89">Kinross-shire</option>
                                    <option value="57">Kirkcudbrightshire</option>
                                    <option value="58">Lanarkshire</option>
                                    <option value="21">Lancashire</option>
                                    <option value="22">Leicestershire</option>
                                    <option value="23">Lincolnshire</option>
                                    <option value="2">London</option>
                                    <option value="46">Merionethshire</option>
                                    <option value="24">Merseyside</option>
                                    <option value="59">Midlothian</option>
                                    <option value="47">Monmouthshire</option>
                                    <option value="48">Montgomeryshire</option>
                                    <option value="60">Moray</option>
                                    <option value="61">Nairnshire</option>
                                    <option value="25">Norfolk</option>
                                    <option value="26">North Yorkshire</option>
                                    <option value="27">Northamptonshire</option>
                                    <option value="28">Northumberland</option>
                                    <option value="29">Nottinghamshire</option>
                                    <option value="62">Orkney</option>
                                    <option value="30">Oxfordshire</option>
                                    <option value="63">Peebleshire</option>
                                    <option value="49">Pembrokeshire</option>
                                    <option value="64">Perthshire</option>
                                    <option value="50">Radnorshire</option>
                                    <option value="65">Renfrewshire</option>
                                    <option value="66">Ross &amp; Cromarty</option>
                                    <option value="67">Roxburghshire</option>
                                    <option value="68">Selkirkshire</option>
                                    <option value="69">Shetland</option>
                                    <option value="31">Shropshire</option>
                                    <option value="32">Somerset</option>
                                    <option value="33">South Yorkshire</option>
                                    <option value="34">Staffordshire</option>
                                    <option value="70">Stirlingshire</option>
                                    <option value="35">Suffolk</option>
                                    <option value="36">Surrey</option>
                                    <option value="71">Sutherland</option>
                                    <option value="37">Tyne and Wear</option>
                                    <option value="38">Warwickshire</option>
                                    <option value="72">West Lothian</option>
                                    <option value="39">West Midlands</option>
                                    <option value="40">West Sussex</option>
                                    <option value="41">West Yorkshire</option>
                                    <option value="73">Wigtownshire</option>
                                    <option value="42">Wiltshire</option>
                                    <option value="43">Worcestershire</option>
                                </select>
                            </label>
                        </div>
                    </div><!-- Row Ends /-->
                        
                    <div class="row">
                        <div class="medium-12 small-12 columns">
                            <label>
                                <textarea rows="4" placeholder="Your message ..."></textarea>
                            </label>    
                            <input type="submit" class="button primary" value="Join" />
                        </div>
                    </div><!-- Row Ends /-->
    
                </div><!-- Contact form /-->
           		</div> <!-- right sidebar ends -->

           	    <div class="medium-3 small-12 columns sidebar">
                    <img src="images/shake_hands.jpg" class="">
            	</div><!-- icon-box ends -->
            
    	    </div><!-- row / -->
		</div> 	    	
        <!-- Content Area Ends /-->
        
        <!-- Call to Action box -->
        <div class="call-to-action">
           <div class="row">
                <div class="medium-10 small-12 columns">
                    <h2><i class="fa fa-phone" aria-hidden="true"></i> 	If you Have Any Questions Call Us On <span>(010)123-456-7890</span></h2>
                </div>
                <div class="medium-2 small-12 columns">
                    <a href="#" class="button secondary">Appointment</a>
                </div>
           </div><!-- row /-->
         </div>
        <!-- Call to Action End /-->
        
        <!-- Footer -->
        <?php include'include/footer.php';?>
        <!-- Footer Ends here /-->
        
    </div>
    <!-- Main Container /-->
	
    <a href="#top" id="top" class="animated fadeInUp start-anim"><i class="fa fa-angle-up"></i></a>

    <!-- Including Jquery so All js Can run -->
    <script type="text/javascript" src="js/jquery.js"></script>
    
    <!-- Including Foundation JS so Foundation function can work. -->
    <script type="text/javascript" src="js/foundation.min.js"></script>
    
    <!-- Including Owl Carousel File -->
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    
    <!-- Webful JS -->
    <script src="js/webful.js"></script>
</body>
</html>
