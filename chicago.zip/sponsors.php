<!doctype html>
<html lang="en">
<head>
    <!-- important for compatibility charset -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    
    <title>Webful Education HTML Template | Our Staff</title>
    
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta name="description" content="">
    
    <!-- important for responsiveness remove to make your site non responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- FavIcon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
    
    <!-- Animation CSS -->
    <link rel="stylesheet" type="text/css" href="css/animate.css" media="all" />
    
    <!-- Foundation CSS File -->
    <link rel="stylesheet" type="text/css" href="css/foundation.min.css" media="all" />
    
    <!-- Font Awesome CSS File -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" media="all" />
    
    <!-- Owl Carousel CSS File -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" media="all" />
    
    <!-- Theme Styles CSS File -->
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    
    <!-- Google Fonts For Stylesheet --> 
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CMontserrat:400,700" rel="stylesheet" type="text/css" />
    
    
</head>

<body>
    <!-- Page Preloader -->
    <div id="loading">
        <div id="loading-center">
            <div id="loading-center-absolute">
            	<div id="object"></div>
            </div>
        </div>
    </div>
    <!-- Page Preloader Ends /-->

	<!-- Main Container -->
    <div class="main-container">
    	
        <?php include'include/header.php';?>
        
        <!-- Title Section -->
        <div class="title-section module">
            <div class="row">
        
                <div class="small-12 columns">
                    <h1>Meet Our Staff</h1>
                </div><!-- Top Row /-->
        
                <div class="small-12 columns">
                    <ul class="breadcrumbs">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Features</a></li>
                        <li class="disabled">Gene Splicing</li>
                        <li><span class="show-for-sr">Current: </span> Cloning</li>
                    </ul><!-- Breadcrumbs /-->
                </div><!-- Bottom Row /-->
                
            </div><!-- Row /-->
        </div>
        <!-- Title Section Ends /-->
        
        
        <!-- Content Area Starts -->
        <div class="module">
	    	<div class="row">
            	<!-- Welcome Message -->
			    <div class="medium-4 small-12 columns">
                 	<img  alt="" src="images/help/our_staff1.jpg" class="thumbnail" />
                </div>
                <div class="medium-8 small-12 columns  staff-introduction">
                    <h2>Our Professional Staff Helps You Right!</h2>                     
                    <p>Nulla facilisi. Donec vel feugiat urna, vel sagittis enim. Quisque eros odio, cursus id libero ac, ornare viverra quam. Vestibulum diam diam, varius id tortor vitae, gravida congue risus. Fusce vitae ex vitae neque dignissim vulputate. Fusce et massa sodales ex scelerisque finibus. Vestibulum porttitor erat lacus, id tincidunt ex luctus nec. Suspendisse tempus porttitor libero, eu cursus ipsum. Phasellus et gravida neque, quis porttitor metus. Phasellus tempor enim enim, eget interdum quam vulputate sed. Maecenas ac dolor justo. Maecenas rhoncus, metus a condimentum suscipit, purus ligula sollicitudin nisi, scelerisque porttitor metus odio vel nisl. In hac habitasse platea dictumst. Vivamus ut lacus diam. Vestibulum porttitor erat lacus, id tincidunt ex luctus nec. Suspendisse tempus porttitor libero.</p>
                </div>
    			<!-- Welcom Message Ends -->
	        </div><!-- Row ends -->
		</div>
	    <!-- Content Area Ends -->
        
        
        <!-- Meet your Team Sect -->
        <div class="module">
        	<div class="row">
            
            	<div class="section-title">
            		<h2><span>Management</span></h2>
            	</div><!-- section title end -->

                <div class="medium-4 small-12 columns">
                	<div class="shadow">
                        <div class="staff-box">
                            <a href="single-teacher.html "><img  alt="" src="images/help/mange_1.jpg" /></a>
                            <div class="staff-links">
                                <ul class="menu">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                </ul>                             
                            </div><!-- staff links /-->
                         </div><!-- staff box /-->       
                         <div class="staff-detail">
                            <h4><a href="single-teacher.html ">Mr Joe Vet</a><br><span>Manager</span></h4>
                            <p>Nulla facilisi. Donec vel feugiat urna, vel sagittis enim. Quisque eros odio, cursus id libero ac, ornare viverra quam. Vestibulum diam diam, varius id tortor vitae, gravida congue risus.</p>
                           	<ul class="no-bullet">
                               <li>Monday - Friday : 9:00 - 15:00</li>
                               <li>Saturday - Sunday :  10:00 - 15:00</li>
                         	</ul>
                            <a href="single-teacher.html" class="small-button">Read More &raquo;</a>                                                                                    
                   		 </div>                                                
                    </div>                    
                </div><!-- Staff -->
                
                <div class="medium-4 small-12 columns staff-box">
                    <div class="shadow">
                    	<div class="staff-box">
                            <a href="single-teacher.html "><img  alt="" src="images/help/teacher4.jpg" /></a>
                            <div class="staff-links">
                                <ul class="menu">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                </ul>                             
                            </div><!-- staff links /-->
                        </div>   
                        <div class="staff-detail">
                            <h4><a href="single-teacher.html ">Mr Joe Vet</a><br><span>Manager</span></h4>
                            <p>Nulla facilisi. Donec vel feugiat urna, vel sagittis enim. Quisque eros odio, cursus id libero ac, ornare viverra quam. Vestibulum diam diam, varius id tortor vitae, gravida congue risus.</p>
                          	<ul class="no-bullet">
                               <li>Monday - Friday : 9:00 - 15:00</li>
                               <li>Saturday - Sunday :  10:00 - 15:00</li>                               
                         	</ul> 
                            <a href="single-teacher.html" class="small-button">Read More &raquo;</a>     
                        </div>
                    </div>
                </div><!-- Staff -->
                
                <div class="medium-4 small-12 columns staff-box">
                    <div class="shadow">
                    	<div class="staff-box">
                            <a href="single-teacher.html "><img  alt="" src="images/help/mange_3.jpg" /></a>
                            <div class="staff-links">
                                <ul class="menu">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                </ul>                             
                            </div><!-- staff links /-->
                        </div>   
                        <div class="staff-detail">
                            <h4><a href="single-teacher.html ">Mr Joe Vet</a><br><span>Manager</span></h4>
                            <p>Nulla facilisi. Donec vel feugiat urna, vel sagittis enim. Quisque eros odio, cursus id libero ac, ornare viverra quam. Vestibulum diam diam, varius id tortor vitae, gravida congue risus.</p>
                           	<ul class="no-bullet">
                               <li>Monday - Friday : 9:00 - 15:00</li>
                               <li>Saturday - Sunday :  10:00 - 15:00</li>
                         	</ul>
                            <a href="single-teacher.html" class="small-button">Read More &raquo;</a>                           
                        </div>                        
                    </div>                     
                </div><!-- Staff -->

            </div><!-- Row -->
        </div>
        <!-- Meet your Team Ends -->
        
        
        <!-- Meet your Team Sect -->
        <div class="module">
        	<div class="row">
            
            	<div class="section-title">
            		<h2><span>Supporting Staff</span></h2>
            	</div><!-- section title end -->

                <div class="medium-4 small-12 columns ">
                    <div class="shadow">
                        <div class="staff-box">
                            <a href="single-teacher.html "><img  alt="" src="images/help/staff_1.jpg" /></a>
                        	<div class="staff-links">
                                <ul class="menu">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                </ul>                             
                        	</div><!-- staff links /--> 
                        </div><!-- staff box /-->      
                        <div class="staff-detail">
                            <h4><a href="single-teacher.html ">Jhon Doe</a><br><span>Principal</span></h4>
                            <p>Nulla facilisi. Donec vel feugiat urna, vel sagittis enim. Quisque eros odio, cursus id libero ac, ornare viverra quam. Vestibulum diam diam, varius id tortor vitae, gravida congue risus.</p>                                                                                                  
                    		<a href="single-teacher.html" class="small-button">Read More &raquo;</a>
                        </div>                                      
                	</div>
                </div><!-- Staff -->
                
                <div class="medium-4 small-12 columns ">
                    <div class="shadow">
                    	<div class="staff-box">
                            <a href="single-teacher.html "><img  alt="" src="images/help/staff_2.jpg" /></a>
                            <div class="staff-links">
                                <ul class="menu">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                </ul>                             
                            </div><!-- staff links /-->
                        </div><!-- staff box /-->   
                        <div class="staff-detail">
                            <h4><a href="single-teacher.html ">Tina Toug</a><br><span>Senior Teacher</span></h4>
                            <p>Nulla facilisi. Donec vel feugiat urna, vel sagittis enim. Quisque eros odio, cursus id libero ac, ornare viverra quam. Vestibulum diam diam, varius id tortor vitae, gravida congue risus.</p>
                            <a href="single-teacher.html" class="small-button">Read More &raquo;</a>
                        </div>
                    </div>
                </div><!-- Staff -->
                
                <div class="medium-4 small-12 columns">
                    <div class="shadow">
                    	<div class="staff-box">
                            <a href="single-teacher.html "><img  alt="" src="images/help/staff_3.jpg" /></a>
                            <div class="staff-links">
                                <ul class="menu">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                </ul>                             
                            </div><!-- staff links /-->
                        </div><!-- staff box /-->   
                        <div class="staff-detail">
                            <h4><a href="single-teacher.html ">Tina Toug</a><br><span>Senior Teacher</span></h4>
                            <p>Nulla facilisi. Donec vel feugiat urna, vel sagittis enim. Quisque eros odio, cursus id libero ac, ornare viverra quam. Vestibulum diam diam, varius id tortor vitae, gravida congue risus.</p>
                            <a href="single-teacher.html" class="small-button">Read More &raquo;</a>
                        </div>
                    </div>
                </div><!-- Staff -->
				
			</div><!-- Row -->
        </div>
        <!-- Meet your Team Ends -->
		
        
        <!-- Meet your Team Sect -->
        <div class="module">
        	<div class="row">
            	<div class="section-title">
            		<h2><span>Administrative</span></h2>
            	</div><!-- section title end -->

                <div class="medium-4 small-12 columns ">
                    <div class="shadow">
                    	<div class="staff-box">
                            <a href="single-teacher.html "><img  alt="" src="images/help/mange_2.jpg" /></a>
                            <div class="staff-links">
                                <ul class="menu">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                </ul>                             
                            </div><!-- staff links /-->
                        </div><!-- staff box /-->   
                        <div class="staff-detail">
                            <h4><a href="single-teacher.html ">Maria Doe</a><br><span>Accounts Manager</span></h4>
                            <p>Nulla facilisi. Donec vel feugiat urna, vel sagittis enim. Quisque eros odio, cursus id libero ac, ornare viverra quam. Vestibulum diam diam, varius id tortor vitae, gravida congue risus.</p>
                            <a href="single-teacher.html" class="small-button">Read More &raquo;</a>
                        </div>
                    </div>
                </div><!-- Staff -->
                
                <div class="medium-4 small-12 columns ">
                    <div class="shadow">
                    	<div class="staff-box">
                            <a href="single-teacher.html "><img  alt="" src="images/help/teacher2.jpg" /></a>
                            <div class="staff-links">
                                <ul class="menu">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                </ul>                             
                            </div><!-- staff links /-->
                        </div><!-- staf box /-->   
                        <div class="staff-detail">
                            <h4><a href="single-teacher.html ">John Doe</a><br><span>Marketing Manager</span></h4>
                            <p>Nulla facilisi. Donec vel feugiat urna, vel sagittis enim. Quisque eros odio, cursus id libero ac, ornare viverra quam. Vestibulum diam diam, varius id tortor vitae, gravida congue risus.</p>
                            <a href="single-teacher.html" class="small-button">Read More &raquo;</a>
                        </div>
                    </div>
                </div><!-- Staff -->
                
                <div class="medium-4 small-12 columns ">
                    <div class="shadow">
                    	<div class="staff-box">
                            <a href="single-teacher.html "><img  alt="" src="images/help/teacher3.jpg" /></a>
                            <div class="staff-links">
                                <ul class="menu">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                </ul>                             
                            </div><!-- staff links /-->
                        </div>   
                        <div class="staff-detail">
                            <h4><a href="single-teacher.html ">Kitty Kat</a><br><span>Marketing Manager</span></h4>
                            <p>Nulla facilisi. Donec vel feugiat urna, vel sagittis enim. Quisque eros odio, cursus id libero ac, ornare viverra quam. Vestibulum diam diam, varius id tortor vitae, gravida congue risus.</p>
                            <a href="single-teacher.html" class="small-button">Read More &raquo;</a>
                        </div>
                    </div>
                </div><!-- Staff -->

            </div><!-- Row -->
        </div>
        <!-- Meet your Team Ends -->
        
        
        <!-- Our Teachers -->
	    <div class="seminar-events">
	     	<div class="row">
            
                <div class="section-title-wrapper light-title">
                    <div class="section-title">
                        <h2>Reserve Your Seat! </h2>
                        <p>Fill in the Form below to reserve your Seat Asap!</p>
                    </div>
                </div> <!-- Title Ends /-->
            
                <div class="contact-form">
    
                    <div class="row">
                        <div class="medium-6 small-12 columns">
                            <label>
                                <input type="text" value="" placeholder="Your name here..." />
                            </label>    
                        </div>
                        <div class="medium-6 small-12 columns">
                            <label>
                                <input type="text" value="" placeholder="Your last name here..." />
                            </label>
                        </div>
                    </div><!-- Row Ends /-->
                        
                    <div class="row">
                        <div class="medium-6 small-12 columns">
                            <label>
                                <input type="text" value="" placeholder="Enter your Website ..." />
                            </label>    
                        </div>
                        <div class="medium-6 small-12 columns">
                            <label>
                                <input type="text" value="" placeholder="Reason contacting us ..." />
                            </label>
                        </div>
                    </div><!-- Row Ends /-->
                        
                    <div class="row">
                        <div class="medium-6 small-12 columns">
                            <label>
                                <select>
                                    <option value="1">Chose Course</option>
                                    <option value="2">Course One</option>
                                    <option value="3">Course Two</option>
                                </select>
                            </label>    
                        </div>
                        <div class="medium-6 small-12 columns">
                            <label>
                                <select>
                                    <option value="1">Chose Teacher</option>
                                    <option value="2">Teacher One</option>
                                    <option value="3">Teacher Two</option>
                                </select>
                            </label>
                        </div>
                    </div><!-- Row Ends /-->
                        
                    <div class="row">
                        <div class="medium-12 small-12 columns">
                            <label>
                                <textarea rows="4" placeholder="Your message ..."></textarea>
                            </label>    
                            <input type="submit" class="button primary bordered-light" value="Send your message" />
                        </div>
                    </div><!-- Row Ends /-->
    
                </div><!-- Contact form /-->
            
          	</div><!-- row /-->
    	</div>
    	<!-- Our Teachers /-->
            
                   
        <!-- Call to Action box -->
        <div class="call-to-action">
           <div class="row">
                <div class="medium-10 small-12 columns">
                    <h2><i class="fa fa-phone" aria-hidden="true"></i> 	If you Have Any Questions Call Us On <span>(010)123-456-7890</span></h2>
                </div>
                <div class="medium-2 small-12 columns">
                    <a href="#" class="button secondary">Appointment</a>
                </div>
           </div><!-- row /-->
         </div>
        <!-- Call to Action End /-->
        
        <!-- Footer -->
        <?php include'include/footer.php';?>
        <!-- Footer Ends here /-->
        
    </div>
    <!-- Main Container /-->
	
    <a href="#top" id="top" class="animated fadeInUp start-anim"><i class="fa fa-angle-up"></i></a>

    <!-- Including Jquery so All js Can run -->
    <script type="text/javascript" src="js/jquery.js"></script>
    
    <!-- Including Foundation JS so Foundation function can work. -->
    <script type="text/javascript" src="js/foundation.min.js"></script>
    
    <!-- Including Owl Carousel File -->
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    
    <!-- Webful JS -->
    <script src="js/webful.js"></script>
</body>
</html>