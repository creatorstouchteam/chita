<!doctype html>
<html lang="en">
<head>
    <!-- important for compatibility charset -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    
    <title>Gallery | Chicago Telangana Association</title>
    
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta name="description" content="">
    
    <!-- important for responsiveness remove to make your site non responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- FavIcon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
    
    <!-- Animation CSS -->
    <link rel="stylesheet" type="text/css" href="css/animate.css" media="all" />
    
    <!-- Foundation CSS File -->
    <link rel="stylesheet" type="text/css" href="css/foundation.min.css" media="all" />
    
    <!-- Font Awesome CSS File -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" media="all" />
    
    <!-- Owl Carousel CSS File -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" media="all" />
    
    <!-- Lightbox IMage Gallery Plugin CSS -->
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" media="all" />
    
    <!-- Theme Styles CSS File -->
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    
    <!-- Google Fonts For Stylesheet --> 
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CMontserrat:400,700" rel="stylesheet" type="text/css" />
    
    
</head>

<body>
    <!-- Page Preloader -->
    <div id="loading">
        <div id="loading-center">
            <div id="loading-center-absolute">
            	<div id="object"></div>
            </div>
        </div>
    </div>
    <!-- Page Preloader Ends /-->

	<!-- Main Container -->
    <div class="main-container">
    	
        <?php include'include/header.php';?>
        
        <!-- Title Section -->
        <div class="title-section module">
            <div class="row">
        
                <div class="small-12 columns">
                    <h1>Our Gallery</h1>
                </div><!-- Top Row /-->
        
                <div class="small-12 columns">
                    <ul class="breadcrumbs">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Gallery</a></li>
                        <li><span class="show-for-sr">Current: </span> Photos</li>
                    </ul><!-- Breadcrumbs /-->
                </div><!-- Bottom Row /-->
                
            </div><!-- Row /-->
        </div>
        <!-- Title Section Ends /-->
        
        <!-- Content section -->
        <div class="content-section gallery-page module">
        	
            <!-- Gallery Section -->
            <div class="gallery-wrapper module">
                <div class="section-title-wrapper">
                    <div class="section-title">
                        <h2>Our Gallery</h2>
                    </div>
                </div> <!-- Title Ends /-->
                
                <div class="gallery-container">
                
                <div class="course-wrapper">
                
                    <ul class="tabs">
                        <?php 
					include 'include/dbconnect.php';
					$sql="SELECT * FROM `tbl_corporate_cat` ORDER BY `tbl_corporate_cat`.`inc_cat_id` DESC ";
					$query=mysql_query($sql);
					while($row=mysql_fetch_array($query))
					{?><li class="tabs-title" ><a href="gallery.php?id=<?php echo $row['inc_cat_id'];?>"><?php echo $row['cat_name'];?></a></li><?php }?>
                    </ul><!-- tabs nav /-->
                    
                    <!-- Tabs content /-->
                    
                </div>
    
                <?php 
	   $id=$_REQUEST['id'];
	   include 'include/dbconnect.php';
	   $sql="select * from gallery where location='$id' ORDER BY `gallery`.`image_id` DESC ";
	   $query=mysql_query($sql);
	   while($row=mysql_fetch_array($query)){
	  ?><a href="admin/<?php echo $row['path'];?>" data-lightbox="campus-gallery" data-title="Chicago Telangana Association"><img class="gallery-thumb" src="admin/<?php echo $row['path'];?>" alt=""/>
                  </a><?php }?>
                
                </div><!-- Gallery Container /-->
                
            </div>
            <!-- Gallery Section Ends /-->
            
        </div>
        <!-- Content Section Ends /-->
        
        
        <!-- Call to Action box -->
        <div class="call-to-action">
           <div class="row">
                <div class="medium-10 small-12 columns">
                    <h2><i class="fa fa-phone" aria-hidden="true"></i> 	If you Have Any Questions Call Us On <span>(010)123-456-7890</span></h2>
                </div>
                <div class="medium-2 small-12 columns">
                    <a href="#" class="button secondary">Appointment</a>
                </div>
           </div><!-- row /-->
         </div>
        <!-- Call to Action End /-->
        
        <!-- Footer -->
        <?php include'include/footer.php';?>
        <!-- Footer Ends here /-->
        
    </div>
    <!-- Main Container /-->
	
    <a href="#top" id="top" class="animated fadeInUp start-anim"><i class="fa fa-angle-up"></i></a>

    <!-- Including Jquery so All js Can run -->
    <script type="text/javascript" src="js/jquery.js"></script>
    
    <!-- Including Foundation JS so Foundation function can work. -->
    <script type="text/javascript" src="js/foundation.min.js"></script>
    
    <!-- Including Owl Carousel File -->
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    
    <!-- Webful JS -->
    <script src="js/webful.js"></script>
    
    <!-- Including LightBox Plugin Delete if not using -->
    <script src="js/lightbox.min.js"></script>
</body>
</html>